# Project Wireframe — Racket Passport
**Author's context:** home-based tennis stringer, Singapore
**Doc version:** v1.1 — planning / pre-build
**Status:** Wireframe. Nothing here is final; §18 lists the decisions you must make before writing code.
**Doc 1 of 3.** Companions: `racket-passport-FRONTEND.md` (UI, screens, design system) · `racket-passport-BACKEND.md` (data model, services, APIs).
Sections 4 (data model), 5 (recommendation engine), 6 (due-date engine), 7 (auth), 8 (QR/labels), 9 (architecture) and 10 (wireframes) are summarised here and specified in full in the two engineering docs.

> 🚨 **NAME COLLISION — read §16 first.** As of Aug 2026 there is a live product at **racquetpassport.app** called **Racquet Passport**, positioned as *"a digital service-history passport for tennis, squash, and badminton racquets — for players, stringers, and shops."* That is your name and substantially your product. This is not fatal, but it is a decision you have to make before you spend a cent on brand, domain, or stickers.

---

## 0. TL;DR — the one-paragraph thesis

Stringer-management apps already exist and most of them are free or near-free (see §2). Being *another* job tracker is a losing game. Your unfair advantage is **the two databases you already own**: racket specs (weight, balance, swingweight, head size, length, RA) and string specs (elasticity, spin potential, friction, mapped across tension × swing speed). Nobody else in this space has combined those into a *prescriptive engine*. So the product is:

> **A restring recommendation + retention engine, wrapped in a job tracker.**
> The job tracker is the trojan horse. The recommendation engine is the product. The restring-due prediction is the retention loop. The data you accumulate from every logged job is the moat and the exit asset.

Free for players, forever. Paid for stringers, cheap, with the pitch: *"one recovered customer a month pays for the whole year."*

---

## 1. Personas & jobs-to-be-done

### 1.1 Stringer (paying customer)
Three sub-types, and they are **not** the same business:

| Sub-type | Volume | Pain | Willingness to pay |
|---|---|---|---|
| **Home stringer** (you) | 5–40 jobs/mo | Remembering who's due; WhatsApp chaos; no record of what he strung last time | Low but real — S$10–15/mo if it recovers jobs |
| **Pro shop / club** | 100–500 jobs/mo | Queue management, multiple stringers, inventory, payroll, walk-in tickets | Medium–high — S$40–100/mo |
| **Tournament crew** | 200+ in 5 days | Chaos mode: same-day turnaround, player IDs, priority flags | Event-based, will pay a burst fee |

**Build for the home stringer first.** They're the most underserved, the easiest to reach, and they're the ones who churn to paper.

**Jobs-to-be-done (stringer):**
1. "Log this job in under 20 seconds while my hands are dirty."
2. "Tell me who hasn't come back and should have."
3. "Make me look professional to a customer who could just go to the mall shop."
4. "Help me answer *'what should I string?'* without a 10-minute conversation I'm not confident about."
5. "Don't make me do accounting."

### 1.2 Player (free user, the network)
**Jobs-to-be-done (player):**
1. "Is my racket ready?"
2. "What did I have last time? I liked it / I hated it."
3. "What should I try next?" ← this is the hook
4. "Remind me before my strings go dead, not after."

### 1.3 The critical asymmetry
Players don't wake up wanting a stringing app. They *do* want to know what to string. Lead the player experience with the **recommendation quiz**, not with an account signup. Recommendation → "save this" → account.

---

## 2. Competitive landscape (researched Aug 2026)

| Product | Model | Notes |
|---|---|---|
| **Racquet Passport** (racquetpassport.app) | Free to start; player-side "service-history passport" + stringer/shop tools; tennis, squash **and badminton**; "find a trusted stringer nearby" | ⚠️ **Direct name and concept collision.** Same passport metaphor, same three audiences, already multi-sport, already has the stringer-discovery loop. Sign up as a player and as a stringer this week and map exactly what they've built and what they've missed. |
| **STRUNG** (strungapp.com) | Free tier + paid; job tracking, inventory, player portal, analytics, multi-venue on top plan | Closest analogue. Firebase-backed. Has a "String Bot" advisor in the customer portal — watch this, it's encroaching on your wedge. Reported entry pricing around US$12/mo. |
| **StringStar** | Free for players; shops free ≤20 jobs/mo, ~€5/mo Basic, ~€20/mo Pro (≤500 jobs, 5 locations) | Has physics-based tension-loss estimator and 3D-printed QR clips for the racket shaft. **Closest to your differentiator.** Study them hard. |
| **String Maven** | Completely free for stringers; 4,100+ patterns, 1,250+ strings, invoicing | Free is the competition. You must be clearly better, not just present. |
| **Stringjob** | Free base, ~US$5/mo for labels + unlimited customers | Old-school, IART-endorsed. Label printing is the paid hook. |
| **Stringing Cloud** | **Usage-based credits** — you pay per recorded stringing, no monthly flat fee | Used at ATP/WTA events. Pricing model worth stealing for the tournament segment. |
| **Stringster** | Free consumer app; measures string tension/deadness by *sound* | Consumer-side wedge, brand-funded. A "freshness check" feature. |
| **StringLab / StringerPal / StringerPro / RacketStringer** | Mostly free or cheap, indie, single-market | Fragmented long tail. Nobody has won. |

**Read of the market:**
- Job tracking is **commoditised and racing to free.** Do not price it.
- **Nobody has monetised prescription.** The advice layer is where you're differentiated and where players (not just stringers) place value.
- The market is **fragmented and indie-built** — which means (a) low barriers, but also (b) no incumbent with real distribution. An exit is realistic (§17).
- QR-on-racket is already being done (StringStar's clip). Do it, but don't call it your differentiator.

---

## 3. Product scope — MoSCoW

### MUST (v1 / MVP)
- Stringer auth + single-tenant workspace
- Player records, racket instances, job logging in <20s
- String + racket catalogue lookup (your DBs)
- Restring-due calculation + automated WhatsApp/SMS ping
- QR code per racket instance → public status/spec page
- Printable/downloadable label (PDF + PNG, thermal-printer sizes)
- Recommendation engine v1 (rules-based, explainable)
- Player passwordless login + read-only history portal

### SHOULD (v1.1–v1.5)
- Job status pipeline (received → in queue → strung → ready → collected)
- Inventory / reel tracking + low-stock alert
- Price list + invoice + payment link
- Post-job feedback capture ("how did it play?") ← **feeds the model**
- Basic revenue analytics

### COULD (v2)
- Multi-stringer / multi-venue with roles
- Tournament mode (priority queue, bulk intake)
- Player-initiated restring requests / booking slots
- Hybrid setup builder with visual string-bed preview
- Badminton support — **passport layer only, no recommendations** (see §17.3) ← strategically the largest single move available to you
- Squash + padel, same pattern

### WON'T (explicitly out of scope for now)
- Marketplace / "Uber for stringing" (different business, needs supply *and* demand liquidity)
- E-commerce / selling string reels
- Native iOS + Android apps at launch (PWA first)
- Racket customisation / lead-tape balancing tools

---

## 4. Domain model

### 4.1 Entities (conceptual ERD)

```
tenant (stringer business)
  └── stringer_user (1..n, roles: owner/stringer/assistant)
  └── price_list_item (1..n)
  └── inventory_lot (1..n) ──> string_catalog
  └── customer_link (n) ──────> player   [many-to-many: a player can use many stringers]

player (GLOBAL identity, not owned by a tenant)   <<< the network asset
  └── player_profile (NTRP, swing speed, priority, arm history, sessions/week)
  └── racket_instance (1..n)
        ├── qr_code (uuid, short_code)
        ├── ──> racket_catalog
        └── job (1..n)

job (a single stringing event)
  ├── ──> racket_instance
  ├── ──> stringer_user
  ├── mains:  string_catalog + gauge + tension + pre-stretch
  ├── crosses:string_catalog + gauge + tension
  ├── status, timestamps, price, payment_status
  ├── computed: predicted_dead_at, due_at
  └── feedback (1..0..1)  <<< the training label

racket_catalog   [YOUR DB]  weight, balance, swingweight, head_size, length, RA, pattern, beam
string_catalog   [YOUR DB]  material, construction, gauge(s), elasticity, spin_potential, friction
string_perf_grid [YOUR DB]  (string_id, tension, swing_speed) -> performance attributes

recommendation   (inputs snapshot, outputs, engine_version, accepted?, outcome)
notification     (channel, template, scheduled_at, sent_at, status, response)
```

### 4.2 The two design decisions that matter most

**(a) `player` is global, not tenant-owned.**
A player who moves cities, or uses a club stringer for tournaments and you for regular play, keeps one identity and one history. This is what turns your app from "a tool" into "a network." It's also the single hardest thing for a competitor to copy later and the thing an acquirer actually buys. Cost: consent + privacy complexity (§9.3). Worth it.

**(b) `racket_instance` ≠ `racket_catalog`.**
A player owns *this specific Pure Aero*, which has its own QR, its own weight after customisation, its own grommet age, its own job history. Conflating the two kills the whole QR/label feature.

### 4.3 Multi-tenancy & isolation
Postgres row-level security. Every tenant-scoped table carries `tenant_id`; policies enforce `tenant_id = current_tenant()`. `player` and the catalogues are shared/global. Player history is exposed to a stringer **only for jobs that stringer performed**, plus an aggregate summary the player explicitly consents to share ("share my full history with this stringer" toggle).

---

## 5. The recommendation engine (your crown jewel)

### 5.1 Design principle: **rules first, ML never (probably)**
Resist the urge to reach for a model. You will not have enough labelled data for years, and stringers will not trust a black box. Build a **transparent scoring engine with printed reasoning** — "we suggested 24/22 lbs because your racket is 100 sq in with an open 16×19 pattern and you asked for control." That explanation *is* the product. It's what makes the stringer look expert to their customer.

Log everything so that a model becomes possible in year 3 (§17.2).

### 5.2 Inputs

| Source | Fields |
|---|---|
| Player profile | NTRP (1.0–7.0), swing speed (slow/med/fast), priority (control / power / spin / comfort / durability), sessions per week, string-breaker? (breaks in <10h?), arm/elbow history, budget band |
| Racket catalog | head size, string pattern & density, swingweight, static weight, balance, RA/stiffness, length |
| String catalog + perf grid | material family, gauge options, elasticity, spin potential, friction, tension-holding class |
| History | last setup, feedback on last setup, actual observed restring interval |
| Environment | climate (Singapore: hot + humid year-round → different from a Northern-European baseline) |

### 5.3 Output contract

```json
{
  "primary": {
    "mains":  {"string_id": "...", "gauge_mm": 1.25, "tension_lb": 24.0},
    "crosses":{"string_id": "...", "gauge_mm": 1.30, "tension_lb": 22.0},
    "prestretch_pct": 0,
    "confidence": 0.78,
    "expected_playable_hours": 22,
    "reasoning": ["100 sq in open pattern → -1 lb vs baseline", "..."]
  },
  "alternatives": [ {"label": "More arm-friendly", ...}, {"label": "More durable", ...} ],
  "warnings": ["RA 68 + full poly at high tension is a comfort risk for a player with elbow history"]
}
```

Always return **three** options: the pick, a softer/comfort variant, a firmer/durability variant. Choice reduces the feeling of being told what to do, and the click-through on alternatives is a free preference signal.

### 5.4 Tension baseline — worked sketch

```
T_base = manufacturer_mid_tension(racket)          # from your racket DB
       + head_size_adj                             # <98 → +1 ; >104 → -1.5
       + pattern_adj                               # 18x20 dense → -1.5 ; 16x19 open → +0.5
       + swingweight_adj                           # SW >330 → -1
       + family_adj                                # poly -3 to -5 vs synthetic gut baseline
       + swing_speed_adj                           # slow +1.5 / med 0 / fast -1.5
       + ntrp_adj                                  # <3.5 +1 (needs depth) ; >5.0 -1
       + priority_adj                              # control +2 / power -2 / spin -1 / comfort -2
       + stiffness_adj                             # RA >=68 → -1 (comfort)
       + climate_adj                               # persistent high heat/humidity → -0.5 poly

CROSSES = MAINS - 2   (poly mains / soft crosses hybrid: crosses -2 to -4)
Clamp to racket's stated safe range. Never emit outside it.
```

**Gauge selection:**
- Breaks strings <10h, or NTRP ≥4.5 with fast swing → 1.25–1.30 mm
- Priority = spin or feel, doesn't break → 1.20–1.25 mm
- Priority = comfort / arm history → 1.30 mm multifilament or gut hybrid
- Never recommend ≤1.20 mm poly to a self-declared string breaker

**Guardrails (hard rules that override scoring):**
1. Never full poly at >26 lb for anyone with declared elbow/shoulder history.
2. Never poly at all for NTRP < 3.5 with slow swing speed — they can't compress it. Recommend multi or syn gut and *say why*.
3. Never exceed manufacturer range.
4. If confidence < 0.5, degrade gracefully: "here's a safe starting point, we'll tune it after your feedback."

> ⚠️ **All numbers above are illustrative structure, not tuned values.** You are the domain expert — calibrate every coefficient against your own DB and your own bench experience, then A/B against real feedback. Treat §5.4 as the shape of the formula, not the formula.

### 5.5 The feedback loop (the part everyone skips)
72h after a job is marked collected, the player gets one message with **three taps**: 😖 too stiff / 👍 spot on / 🎈 too lively. Plus optional: "when did it start feeling dead?"

That single interaction gives you:
- a labelled datapoint (profile + racket + setup → subjective outcome)
- a per-player `decay_multiplier` for the due-date model (§6)
- a retention touchpoint that isn't a sales message
- a reason for the stringer to look good ("he actually followed up")

**Target: >35% response rate.** If it's under 20%, the message is wrong, not the idea.

---

## 6. Restring-due prediction (the retention engine)

This is *the* feature you led with, and the naive version is bad. The folk rule — *"restring as many times per year as you play per week"* — ignores string type entirely.

### 6.1 Model
Predict a **playable-hours budget**, then convert to a date.

```
playable_hours = base_hours(string_family, gauge)
               × ntrp_factor           # harder hitters kill strings faster
               × swing_speed_factor
               × tension_factor        # higher tension → shorter life
               × player_decay_multiplier   # LEARNED from their feedback history
               × climate_factor        # sustained heat accelerates poly relaxation

due_date = strung_date + (playable_hours / hours_per_week)
```

Rough family ordering for `base_hours` (calibrate yourself): polyester < synthetic gut < multifilament < natural gut on *tension retention*; the ordering flips for *breakage* with big hitters. Poly's dominant failure mode is going dead, not snapping — most players restring far too late.

### 6.2 Two due dates, not one
- **`tension_due`** — strings have gone dead (performance)
- **`breakage_risk`** — for string breakers, probability of snapping mid-match

Ping on whichever comes first. Label them differently in the message; "your strings are dead" and "you're about to snap" are different urgencies.

### 6.3 Adaptive correction
When a player actually returns, compare `actual_interval` to `predicted_interval` and nudge their `decay_multiplier`. After 3 jobs the prediction should be meaningfully personal. **Show this to the stringer** — "prediction accuracy for your customers: 81%" is a retention feature for *your* subscription.

### 6.4 Ping mechanics — do not get this wrong
Notification fatigue kills this product. Rules:
- Ping at **T-7 days**, then **T+0**, then **stop**. Two messages, maximum, per cycle.
- One follow-up at T+21 only if there's an offer attached.
- Never ping the same player from two stringers in the same week — dedupe at the player level, globally.
- Every message carries a one-tap "book now" and a one-tap "snooze 30 days."
- Hard per-player frequency cap, enforced in the notification service, not in application code.
- Player-side global "pause all reminders" toggle. Honour it absolutely.
- **Stringer sees a "due this week" queue and can approve in bulk.** Fully-automated sends are the goal, but let the stringer choose auto vs review for the first 30 days — trust is earned.

---

## 7. Auth design (your Q3 — decided)

**Recommendation: passwordless, phone-first with email fallback. Use a managed provider; do not build this.**

| Persona | Primary | Fallback | Session |
|---|---|---|---|
| Player | WhatsApp OTP (SEA) or SMS OTP | Email magic link | 90 days, sliding refresh |
| Stringer | Email magic link + optional passkey | SMS OTP | 30 days; re-auth for billing/data-export |

**Why WhatsApp over SMS in your market:** near-universal in Singapore/Malaysia/Indonesia, dramatically cheaper than SMS at volume, richer templates, delivery receipts. SMS is the fallback for people who don't have it.

**Gotchas to check before building:**
- Singapore requires registration of alphanumeric SMS Sender IDs (SGNIC/SSIR). Unregistered sender IDs get flagged as "Likely-SCAM." **Verify current requirements and budget the registration.**
- WhatsApp Business Platform requires **pre-approved message templates** for business-initiated messages, and there's a 24-hour customer-service window rule. Your restring reminder is a business-initiated *utility* template — get it approved early, it's a lead time item.
- Rate-limit OTP requests per phone number (5/hour) and per IP. OTP endpoints are the #1 abuse vector and SMS fraud ("SMS pumping") will cost you real money.
- OTP: 6 digits, 5-minute expiry, single-use, constant-time compare, 3 attempts then lockout.

**Zero-friction path that matters most:** a player scanning a QR sticker should see their racket's status **without logging in at all** (§8.3). Login is only needed to edit or see full history.

---

## 8. QR codes & labels (your Q4)

### 8.1 What the QR encodes
A short URL to a **stable public route**: `https://<domain>/r/<short_code>`
- `short_code` = 8-char base32, per `racket_instance`, permanent for the racket's life
- Never encode PII in the QR itself
- Never encode a JSON blob — the sticker outlives the data

### 8.2 The label
Two variants:

```
┌─────────────────────────────────┐   ┌──────────────────┐
│ ALEX TAN            04 Mar 26   │   │  [QR]            │
│ Pure Aero 98                    │   │  Alex T. · 24/22 │
│ ─────────────────────────────── │   │  RPM Blast 1.25  │
│ M: RPM Blast 1.25    @ 24 lb    │   │  04 Mar 26       │
│ X: Xcel 1.30         @ 22 lb    │   └──────────────────┘
│ Due: ~18 May 26        [ QR ]   │      Small (racket
│ YourShop · 9xxx xxxx            │       throat / butt cap)
└─────────────────────────────────┘
  Large (bag tag / bag receipt)
```

### 8.3 The scan experience (three audiences, one URL)
Resolve by session state:
- **Anon scan** → public page: racket model, current setup, date strung, due date, stringer name + "book a restring" button. *No player name, no phone number.*
- **Owning player, logged in** → full history, feedback prompts, "request restring."
- **Stringer of that job, logged in** → jump straight into edit/relog. This is a genuine speed win in the shop: scan → "restring same as last time" → done in 5 seconds.

### 8.4 Printing
- Export **PDF (vector) and PNG (300dpi)** — the "download and add to sticker print" you asked for
- Presets: 89×36mm (Dymo 99012), 62mm continuous (Brother QL), 40×30mm (Niimbot D11 — cheap, very popular with home stringers, ~S$25 device)
- Ship a **Avery A4 sheet layout** for people with no label printer at all — 24-up, aligned to a standard template
- Quiet zone ≥4 modules, error correction level M, minimum 15mm printed size. Test scans on a *worn, sweaty* sticker before you ship.

---

## 9. System architecture

### 9.1 Stack recommendation (optimised for one person shipping)

| Layer | Pick | Why |
|---|---|---|
| Frontend | **Next.js (App Router) as an installable PWA** | One codebase, works on the stringer's iPad and the player's phone, camera API for QR scanning works fine, no app-store review latency. Ship native later via Expo when you have retention proof. |
| Backend | Next.js route handlers + **Postgres (Supabase or Neon)** | RLS gives you multi-tenancy for free. Don't build a separate API service yet. |
| Auth | Supabase Auth / Clerk | Phone OTP + magic link out of the box. See §7. |
| Jobs/cron | Supabase cron or Inngest/Trigger.dev | Due-date sweeps, notification scheduling, retries |
| Messaging | Twilio or 360dialog (WhatsApp BSP) + Resend (email) | Abstract behind your own `NotificationService` — you *will* switch providers on price |
| Payments | Stripe; **HitPay or Stripe PayNow for SG** | PayNow/QR is table stakes locally |
| Files | S3/R2 for label PDFs, racket photos | |
| Hosting | Vercel + managed Postgres | |
| Analytics | PostHog (product) + a simple metrics table | |
| Errors | Sentry | |

**Explicit anti-recommendation:** don't start with microservices, don't start with a native app, don't start with a mobile-first *and* desktop-first design, don't build your own auth. You are one person with a stringing business to run.

### 9.2 Notification service (the piece to build properly)

```
due_sweep (daily cron)
   → find jobs where due_at ∈ [today+7, today+7] or due_at = today
   → filter: player not paused, not already notified this cycle,
             global frequency cap OK, tenant plan allows
   → enqueue notification (idempotency_key = job_id + stage)
   → tenant auto-send? → send : place in "Due this week" review queue
   → send via channel ladder: WhatsApp → SMS → email
   → record delivery + response; attribute any resulting booking back to the ping
```

Idempotency keys are non-negotiable. Double-texting a customer about their racket is the fastest way to get a stringer to cancel.

### 9.3 Privacy & data (do this early, it's an exit blocker)
- Singapore **PDPA**: consent for marketing messages, purpose limitation, access & correction rights, and a **Do Not Call registry** check obligation for telephone-number marketing. Reminders about a service the player bought are arguably transactional, not marketing — **get this checked by someone qualified**, because the whole product hinges on it.
- Data ownership terms: the stringer owns their customer relationships; **you** need explicit licence to use anonymised, aggregated job data for model improvement. Put this in the ToS from day one. Retrofitting it after 50k jobs is impossible, and it is precisely the asset an acquirer pays for (§17).
- Player right to export and delete. Build the export endpoint in v1; it costs 2 hours now and 2 weeks later.
- **Check the provenance of your racket and string databases.** If any of it was scraped from a manufacturer or retailer, you have a commercial-use problem that will surface during acquisition due diligence. Establish clean rights now — measured-in-house data is the strongest position.

---

## 10. Screen wireframes

### 10.1 Stringer — Home / Today
```
┌────────────────────────────────────────────┐
│  Today                        [+ New Job]  │
├────────────────────────────────────────────┤
│  IN QUEUE  3      READY  2     DUE WK  7   │
├────────────────────────────────────────────┤
│  ⚡ Due this week (7)          [Review →]  │
│     5 auto-send Wed · 2 need your input    │
├────────────────────────────────────────────┤
│  QUEUE                                     │
│  ▸ Alex Tan — Pure Aero 98   RPM 1.25 24/22│
│    dropped 2h ago              [Mark strung]│
│  ▸ Wei Ming — Ezone 100      Hybrid  [→]   │
├────────────────────────────────────────────┤
│  READY FOR PICKUP                          │
│  ▸ Sarah L. — Blade 98   notified 1d ago   │
├────────────────────────────────────────────┤
│  ⚠ Low stock: RPM Blast 1.25 — 12m left    │
└────────────────────────────────────────────┘
```

### 10.2 Stringer — New Job (the 20-second flow)
```
Step 1  [ 📷 Scan QR ]  or  [ Search customer ]
        → known racket? jump to Step 3 pre-filled

Step 2  Customer: Alex Tan ▾   Racket: Pure Aero 98 ▾   [+ new]

Step 3  ┌ LAST TIME ──────────────────────────┐
        │ RPM Blast 1.25 @ 24 / 22  · 04 Mar  │
        │ Feedback: 👍 spot on                 │
        │        [ SAME AGAIN ]  ← 1 tap, done │
        └──────────────────────────────────────┘
        or  [ ✨ Get recommendation ]  [ Enter manually ]

Step 4  Price S$ 35  ·  Ready by [ Thu 6pm ▾ ]
        [✓] Notify customer when ready
        [ SAVE & PRINT LABEL ]
```
> **"SAME AGAIN" is the single most important button in the product.** Most jobs are repeats. Optimise brutally for it.

### 10.3 Recommendation flow (shared by stringer + player)
```
┌────────────────────────────────────────────┐
│  Find your setup                    1 / 4  │
│  Your racket                               │
│  [ Search: Babolat Pure Aero 98    ] 🔍    │
│  → 98 sq in · 16×19 · 305g · SW 324 · RA 67│
│──────────────────────────────────────────  │
│  2/4  Level      [2.5][3.0][3.5]●[4.0][4.5]│
│  3/4  Swing      ( ) Slow ( ) Med (●) Fast │
│  4/4  Priority   [Control][Power][Spin]    │
│                  [Comfort][Durability]     │
│                                            │
│  Elbow/shoulder issues?  ( ) Yes  (●) No   │
│  Break strings often?    (●) Yes  ( ) No   │
└────────────────────────────────────────────┘
        ↓
┌────────────────────────────────────────────┐
│  ✦ RECOMMENDED                             │
│  Mains   RPM Blast   1.25mm   @ 24 lb      │
│  Crosses RPM Blast   1.25mm   @ 22 lb      │
│  Expected life ≈ 22 hrs (~5 weeks for you) │
│                                            │
│  Why this ▾                                │
│   • 98 sq in + 16×19 → tension near mid    │
│   • Fast swing + control → +2 lb           │
│   • You break strings → 1.25 not 1.20      │
│   • RA 67 is firm → we stayed off 26 lb    │
│                                            │
│  ALSO CONSIDER                             │
│  ○ Softer on the arm  → poly/multi hybrid  │
│  ○ Lasts longer       → 1.30 shaped poly   │
│                                            │
│  [ Use this setup ]   [ Save to my profile]│
└────────────────────────────────────────────┘
```

### 10.4 Player — Portal
```
┌────────────────────────────────────────────┐
│  My Rackets                                │
│  ┌──────────────────────────────────────┐  │
│  │ Pure Aero 98            ●●●●○  73%   │  │
│  │ RPM Blast 1.25 @ 24/22               │  │
│  │ Strung 04 Mar · Due ~18 May          │  │
│  │ [ Request restring ]  [ History ]    │  │
│  └──────────────────────────────────────┘  │
│  ┌──────────────────────────────────────┐  │
│  │ Blade 98                ●○○○○  11%   │  │
│  │ ⚠ Overdue by 12 days                 │  │
│  └──────────────────────────────────────┘  │
│                                            │
│  [ ✨ Find a new setup ]                   │
│  Reminders: WhatsApp ▾   [ Pause all ]     │
└────────────────────────────────────────────┘
```
The **string-life bar** is the emotional core of the player app. It makes an invisible, gradual degradation *visible*. That's the whole retention mechanic in one UI element.

### 10.5 Public QR landing (anonymous)
```
        [ shop logo ]
   Babolat Pure Aero 98
   ────────────────────────
   Strung   04 Mar 2026
   Setup    RPM Blast 1.25
            24 / 22 lb
   Status   ✅ Ready for pickup
   ────────────────────────
   Strung by YourShop
   [ Book a restring ]
   [ Is this yours? Claim racket ]
```
"Claim racket" is your **viral loop**: every sticker is an acquisition surface for a free player account.

---

## 11. Build roadmap

Assumes solo, part-time (~15 h/week) around a stringing business. Halve the timeline with a part-time contractor.

### Phase 0 — Validate (Weeks 1–3) · *do not skip*
- Interview **12 stringers** (home + shop + one club). Script: "walk me through your last 5 jobs." Watch, don't pitch.
- Ask one question that matters: **"what would you pay per month for this?"** then **"okay, would you pay that today?"** The gap between those answers is your real pricing.
- Log your own last 50 jobs manually into a spreadsheet in the target schema. You'll find 6 modelling mistakes for free.
- Get 3 verbal LOIs. If you can't get 3 stringers to say "text me when it's ready," rethink.
- **Deliverable:** validated schema + 3 design partners.

### Phase 1 — MVP (Weeks 4–13)
Scope-locked. No additions.
- Auth (stringer + player), tenant setup
- Catalogue import: your racket + string DBs, with a de-dupe/normalisation pass
- Customer + racket instance CRUD
- Job logging with "SAME AGAIN"
- Due-date v1 + WhatsApp reminder with review queue
- QR generation + label PDF/PNG export
- Public scan page
- Recommendation engine v1 + reasoning strings
- **Deliverable:** you run your entire business on it for 4 weeks. Nobody else. Fix everything that annoys you.

### Phase 2 — Design partners (Weeks 14–20)
- Onboard the 3 partners free, in exchange for weekly 20-min calls
- Job status pipeline, feedback capture, basic analytics
- Inventory + low stock
- Onboarding flow good enough that a stranger succeeds unattended
- **Gate to Phase 3:** ≥2 of 3 partners have logged >30 jobs and say they'd pay.

### Phase 3 — Monetise (Weeks 21–30)
- Billing, plans, limits (§12)
- Invoicing + payment links (Stripe / PayNow)
- Public marketing site + the **free recommendation tool as the SEO/viral front door**
- Launch: Talk Tennis / Reddit r/10s / GSS & IART communities / local FB stringer groups
- **Target: 25 paying stringers.**

### Phase 4 — Expand (Months 8–14)
- Multi-stringer + roles → clubs and pro shops (higher ARPU)
- Tournament mode
- **Badminton, passport layer only** — job log, QR, reminders, max-tension guardrail, crowdsourced catalogue. Recommendation module hidden, not stubbed (§17.3)
- Player-side growth loop: claim-racket → recommendations → find-a-stringer

### Phase 5 — Scale or sell (Months 15–36)
See §17.

---

## 12. Pricing strategy

### 12.1 Principles
1. **Free for players. Forever. No asterisk.** Players are your network, not your revenue.
2. **Never charge for the job tracker.** It's free elsewhere. Charge for *automation and prescription*.
3. **Cap the free tier by volume, not by feature.** A free stringer with 10 jobs/month must have a genuinely great experience — they're your distribution and they grow into paying.
4. **Metered messaging costs get passed through.** WhatsApp/SMS is real COGS; never let a heavy sender destroy your margin.

### 12.2 Proposed tiers

| | **Free** | **Solo** | **Shop** | **Club/Tournament** |
|---|---|---|---|---|
| Price | S$0 | **S$12/mo** (S$120/yr) | **S$39/mo** (S$390/yr) | from S$99/mo or event packs |
| Jobs/mo | 15 | Unlimited | Unlimited | Unlimited |
| Customers | 30 | Unlimited | Unlimited | Unlimited |
| QR + labels | ✓ | ✓ branded | ✓ branded | ✓ |
| Recommendation engine | 5/mo | Unlimited | Unlimited | Unlimited |
| Auto reminders | Manual only | ✓ automated | ✓ automated | ✓ |
| Included messages | 20/mo | 250/mo | 1,000/mo | 5,000/mo |
| Inventory | — | ✓ | ✓ + valuation | ✓ |
| Invoicing/payments | — | ✓ | ✓ | ✓ |
| Analytics | Basic | ✓ | ✓ + per-stringer | ✓ + event reports |
| Users | 1 | 1 | 5 | Unlimited |
| Venues | 1 | 1 | 3 | Unlimited |

**Add-ons:** message top-ups (S$8 / 250); custom-domain player portal (S$10/mo); starter label kit (physical, resold).

**Regional pricing:** SEA/LatAm/India at ~50–60% of US/EU list. Same product, different card country. Your first market is price-sensitive and your addressable market in SEA is large.

### 12.3 The pitch, verbatim
> "A restring is S$35. If reminders bring back **one** customer you'd have lost, the year is paid for twice over. Everything else is free."

Put an **ROI calculator** on the pricing page: *jobs/month × price × recovered-rate*. Let the number make the argument.

### 12.4 What NOT to do
- ❌ Per-seat pricing at the low end — home stringers are always 1 seat, it signals "enterprise"
- ❌ Free trial requiring a card — this audience bounces
- ❌ Charging players anything at launch — kills the network before it forms
- ❌ Pure usage-based at the low end — unpredictable bills terrify small operators (it *does* work for tournaments; Stringing Cloud proved that)
- ❌ Undercutting to S$5 — you'll attract churn and can't fund support

### 12.5 Later revenue lines (v2+, don't build now)
- **Affiliate on string sales** — you know exactly what each player uses and exactly when they'll need more. Attach a "reorder your reel" flow. This is high-intent commerce and it may eventually exceed subscription revenue.
- **Brand-sponsored placement** in the recommendation engine — ⚠️ handle with extreme care. The moment recommendations are pay-to-play, your credibility (the entire product) evaporates. If you ever do it, it must be a clearly-labelled separate "try this" slot, never the algorithm.
- **Payment take-rate** — small % on processed volume once payments are entrenched.
- **Data/insights products** for brands (aggregated, anonymised, consented) — see §17.2.

---

## 13. Go-to-market

**Wedge:** the free public **"What should I string?"** tool. No login. Great SEO ("best tension for Pure Aero 98", "poly vs multifilament for tennis elbow"). Every result ends with *"Get this strung — find a stringer"* / *"Are you a stringer? Log jobs free."*

**Channels, in priority order:**
1. **You.** You're a home stringer with customers and peers. First 10 users come from your own network and local FB/WhatsApp stringer groups.
2. **Stringer communities:** GSS/IART, Talk Tennis, r/10s, national stringers' associations. Show up as a stringer, not a founder.
3. **Content:** the tension-loss explainer, gauge guide, hybrid setups. This audience genuinely reads this stuff.
4. **QR stickers in the wild.** Every racket on a court is a billboard. Make the sticker beautiful and small.
5. **Clubs & academies** — one club onboards 200 players at once. Highest-leverage channel, slowest sales cycle.
6. **Tournaments** — high visibility with serious stringers; comp the software for the event in exchange for logo + intros.

**Onboarding must clear one bar:** a stringer imports/keys their customers and logs their first job in **under 10 minutes**, unassisted. Offer white-glove CSV/spreadsheet import for anyone with >50 customers. Do it manually yourself for the first 30 accounts.

---

## 14. Metrics

**North star:** *jobs logged per active stringer per month.* It captures adoption, habit, and business health in one number.

| Stage | Metric | Target |
|---|---|---|
| Activation | Signup → first job logged (24h) | >50% |
| Activation | Signup → 5 jobs logged (7d) | >30% |
| Habit | Jobs/active stringer/month | >20 |
| **Core loop** | Reminder → booking conversion | **>15%** |
| Core loop | Feedback response rate | >35% |
| Core loop | Due-date prediction accuracy (±7d) | >70% by job 4 |
| Network | Players with claimed account / total players | >25% |
| Business | Free → paid conversion | >8% |
| Business | Monthly logo churn | <4% |
| Business | Gross margin (after messaging COGS) | >80% |

**The metric that decides the whole business:** *reminder → booking conversion.* If pings don't bring customers back, the product has no reason to be paid for. Instrument it before you instrument anything else.

---

## 15. Risks

| Risk | Severity | Mitigation |
|---|---|---|
| **Name + concept collision with Racquet Passport** | **High** | Resolve before any brand spend (§16). Assess how built-out they actually are — if they're mature, it changes positioning; if they're a landing page, it's mainly a naming problem. |
| Job tracking is free everywhere | **High** | Don't compete there. Prescription + automation is the paid surface. |
| STRUNG's "String Bot" / StringStar's tension model close your gap | **High** | Speed + your proprietary tension×swing-speed grid. Ship the engine in the MVP, not v2. |
| Stringers won't change habits (paper/whiteboard works) | **High** | 20-second logging, "SAME AGAIN", free tier, white-glove import. Habit change is the real competitor, not other apps. |
| Notification fatigue → players opt out en masse | **High** | Hard caps, global dedupe, snooze, pause. §6.4 is not optional. |
| WhatsApp template rejection / policy change | Medium | Multi-channel ladder from day one; abstract the provider. |
| Messaging COGS eats margin | Medium | Included quotas + metered top-ups. |
| Racket/string DB provenance | Medium | **Audit rights now.** It's an acquisition blocker later. |
| PDPA / DNC exposure on reminders | Medium | Explicit consent capture at player creation; get qualified advice. |
| Recommendation liability (injury claims) | Low–Med | Hard comfort guardrails, clear "consult your stringer" framing, ToS. |
| Seasonality + small TAM per market | Medium | Multi-sport (badminton, padel, squash) and multi-geo early. |
| Founder bandwidth (you have a business to run) | **High** | Ruthless scope lock in Phase 1. Run your own shop on it — dogfooding *is* the QA budget. |

---

## 16. Naming — the Racket Passport problem

**The name is excellent.** "Passport" is the right metaphor for exactly the reason it's the right architecture: the racket carries a travel document that stays with it across stringers, shops and countries. The name *is* the §4.2 global-identity decision, expressed in two words. It also generalises across sports without renaming.

**The problem:** someone else got there first. `racquetpassport.app` is live, uses the identical metaphor and tagline framing, and already covers tennis, squash and badminton for players, stringers and shops.

### Your options

| Option | Assessment |
|---|---|
| **A. Use "Racket Passport" anyway** (`-ck-` spelling, different TLD) | ⚠️ Risky. Confusingly similar marks in the same class, same industry, same product category is roughly the textbook definition of a trademark problem — *and* you'd fight them for every search result forever. If they file first, you may be forced to rebrand after you've printed thousands of stickers. **Do not do this without legal advice.** |
| **B. Keep the passport *concept*, change the *name*** | ✅ **Recommended.** The metaphor is free; the wordmark isn't. Keep "your racket's passport" as product language, UI copy, and the name of the *feature* (the passport page, the stamp on each job) — but own a different brand. |
| **C. Pick a name from the stringing/prescription side instead** | ✅ Also good, and better matches your actual wedge (§0). Your differentiator isn't the history log — it's the recommendation engine. Name the thing you're actually best at. |
| **D. Contact them** | Worth a single email. They may be tiny, stalled, or open to selling the domain. Cheap to ask; don't negotiate against yourself. |

### Candidate names to check
Prescription-led: `Tensio`, `Stringcraft`, `Gutfeel`, `Truetension`, `Setpoint`.
Passport-adjacent but distinct: `Stringbook`, `Racketlog`, `Servicebook`, `Stamped`.
Avoid entirely: anything with "Strung", "Stringer", or "Racquet/Racket" + Pro/App/Pal — that namespace is saturated (STRUNG, StringerPro, StringerPal, StringLab, StringStar, StringMaven, Stringjob) and you will lose SEO permanently.

### Do this before spending on brand
1. Search **IPOS (Singapore)** and **USPTO/EUIPO** for "passport" marks in classes 9 and 42.
2. Check `.com` availability — own the `.com`, not a `.app` workaround.
3. Check app-store name availability on both stores.
4. **Get 30 minutes with a Singapore IP lawyer before you commit.** This costs a few hundred dollars and can save you a full rebrand. I'm not a lawyer and the table above is orientation, not legal advice.

**Interim:** keep using "Racket Passport" internally as the codename — it's a good north star for what the product is. Just don't put it on anything public until §16 is resolved.

---

## 17. Exit strategy

> ⚠️ I'm not a financial or legal advisor. The multiples and structures below are general market context to orient your planning, not valuation advice. Get a corporate advisor before signing anything.

### 17.1 Build the asset the buyer actually wants
Nobody acquires a job tracker. What gets bought:
1. **Proprietary outcome data.** Every logged job = (player profile + racket specs + string + gauge + tension + climate + subjective feedback + *actual* observed string life). At 100k+ jobs this is the largest real-world string-performance dataset in existence. String and racket manufacturers cannot buy this anywhere. **This is the asset.** Protect it with clean data rights (§9.3) from day one.
2. **The player network.** Global player identities with verified equipment and purchase cadence — high-intent, hard to rebuild.
3. **Distribution into stringers/shops** — a channel a brand can push product through.
4. **Predictable, high-margin, low-churn MRR.**

### 17.2 Buyer map

| Buyer type | Examples | Why they'd buy | What to optimise |
|---|---|---|---|
| **String & racket brands** | Babolat, Wilson, Head, Yonex, Luxilon, Solinco, Tecnifibre | Consumption data + a recommendation surface that shapes what players buy. Strategically the highest-value buyer. | Data rights, player count, brand-neutral credibility (don't sell the algorithm before you sell the company) |
| **Retail / e-commerce** | Tennis Warehouse, Tennis-Point, Decathlon, regional distributors | Restring reminder = a perfectly-timed purchase trigger. Direct revenue attribution. | Commerce attach rate, reorder conversion |
| **Club/court management SaaS** | Playtomic, CourtReserve, Skedda, ClubSpark, padel platforms | Adjacent module, same buyer, instant cross-sell into their installed base. **Most likely realistic acquirer.** | Multi-sport, clean API, club-tier ARPU |
| **Sports SaaS roll-ups / PE** | Vertical SaaS consolidators | Cash-flowing niche asset | Rule-of-40-ish profile, <4% churn, low support load |
| **Federations / tournament ops** | National associations, ITF-adjacent | Tournament stringing infrastructure | Tournament mode credibility |

### 17.3 Multi-sport: **badminton without the data**

Badminton is still the biggest strategic prize available to you — restring frequency is higher, volume per shop is far greater, and the tooling is worse. You're sitting in the best market on earth for it. But you've correctly identified the blocker: **you don't have badminton racket or string spec data, so you can't ship the recommendation engine there.**

That's fine, because the product has two separable layers and only one of them needs your databases:

| Layer | Needs spec data? | Badminton-ready today? |
|---|---|---|
| Passport, job log, QR/label, due-date reminders, player portal, invoicing | **No** — just string name, tension, date, play frequency | ✅ **Yes** |
| Recommendation engine (§5), tension-vs-swing-speed modelling | **Yes** | ❌ No |

**So: ship badminton as passport-only.** A badminton stringer's current alternative is a whiteboard and a WhatsApp group. Job tracking + automated restring reminders + a QR sticker is already a large upgrade for them, with zero prescription. Don't pretend otherwise in the UI — hide the recommendation module for badminton rather than shipping a bad version of it. A visibly-absent feature is fine; a confidently-wrong tension recommendation on a frame with a 24 lb ceiling will crack someone's racket and end your credibility in that community overnight.

**One badminton feature you *can* build with almost no data, and should:** a **max-tension guardrail.** Over-tensioning is the dominant failure mode in badminton — frames are rated (roughly 20–30 lb depending on model) and exceeding it cracks them. You only need one number per racket model, which is published by manufacturers and printed on the frame itself. A warning at job entry — *"this frame is rated to 24 lb, you've entered 28"* — is genuinely useful, cheap to build, and gives you a reason to start collecting badminton racket records.

**How the badminton catalogue gets built — by your users, not by you:**
1. Ship badminton with an empty-ish catalogue and a fast "add a racket / add a string" flow.
2. Every stringer who logs an unknown racket contributes one record: model, weight class (3U/4U/5U), balance, flex, **max tension**.
3. You normalise and de-dupe centrally (this is manual for the first few thousand — budget for it).
4. Strings are even simpler: badminton string specs are thin industry-wide, and the practical axes are gauge (roughly 0.61–0.70 mm) and the repulsion-vs-durability tradeoff. Two dimensions, not twelve.
5. At ~5,000 logged badminton jobs with feedback attached, you have enough real-world outcome data to build a badminton engine **from observed results rather than published specs** — which is a better dataset than the one you have for tennis.

That last point is worth sitting with: **the crowdsourced route produces a more defensible asset than licensed spec sheets ever would.** Manufacturer specs are available to any competitor. "What 5,000 real jobs across 400 frames actually felt like to the player" is not.

**Revised sequencing:**
- Month 12 — badminton passport layer live (no prescription), max-tension guardrail, crowdsourced catalogue
- Month 18–24 — badminton recommendation engine v1, trained on your own accumulated job outcomes
- Squash and padel follow the same pattern; padel's growth curve makes it the better third sport

This also de-risks §17.1: your data moat now compounds in a sport where *nobody* has the spec data, rather than one where the incumbents can buy it.

### 17.4 Milestones toward a sale

| Horizon | Goal |
|---|---|
| 0–12 mo | 100 paying stringers, 50k jobs logged, SG/MY proven, prediction accuracy >70% |
| 12–24 mo | Badminton passport live + catalogue crowdsourcing running, 500 paying stringers across 3+ countries, US$25–40k MRR, churn <4%, first brand conversation (data pilot / co-marketing) |
| 24–36 mo | US$80k+ MRR, commerce attach live, 250k+ jobs, 2+ inbound strategics → run a process |

### 17.5 Structuring
- **Never sign an exclusive data deal with one brand pre-exit.** It caps you to one buyer and destroys competitive tension.
- Run a process with ≥3 interested parties. A single bidder sets their own price.
- Small vertical SaaS commonly trades on a multiple of ARR; strategic buyers acquiring *data and channel* rather than revenue can pay well above financial multiples. Both statements are context, not a promise — the range is wide and depends entirely on growth, churn, and how badly a specific buyer wants it.
- Expect earnout on a strategic sale. Model your outcome on the guaranteed portion.
- Keep the cap table clean. Bootstrapping this to profitability is very plausible and materially increases your share of any exit.
- **Also consider not selling.** A profitable, low-headcount vertical SaaS throwing off six figures a year, run by someone who loves the sport, is a genuinely excellent outcome. "Exit" and "big bucks" aren't the only shape of a win.

---

## 18. Decisions you need to make before writing code

1. **Sport scope at launch** — recommend: **tennis-only UI, sport-aware schema, from day one.** You lack badminton spec data (§17.3), so badminton can't launch with prescription — but the schema decision is expensive to retrofit and costs almost nothing now. Add a `sport` column to `racket_catalog`, `string_catalog`, `racket_instance` and `job`, and make the recommendation module conditional on sport. Ten minutes now, ten weeks later.
1b. **Catalogue contribution model** — do stringers get to add missing rackets/strings from day one, even in tennis? (Recommend yes. It's how the badminton catalogue eventually gets built, and you want the moderation workflow battle-tested on tennis first, where you can spot bad records.)
2. **Player identity: global or tenant-scoped?** (§4.2 — recommend global; it's the network and the exit asset, but it costs you consent complexity.)
3. **Auto-send reminders by default, or review queue by default?** (Recommend review queue for 30 days, then auto.)
4. **Data rights language in ToS** — draft before your first user.
5. **Racket/string DB provenance** — where did it come from, and can you commercialise it?
6. **Free-tier ceiling** — 15 jobs/month is a guess. Look at your own volume distribution and your 12 interviews.
7. **Home market** — Singapore only, or SG+MY from day one? (Affects payments, messaging, pricing.)
8. **Build alone or hire a contractor for Phase 1?** Be honest about 15 h/week against a 10-week scope.
9. **Recommendation engine: player-facing at launch, or stringer-only?** (Player-facing is your growth loop; stringer-only is safer for credibility. Recommend player-facing with "confirm with your stringer" framing.)

---

## 19. First six things to do this week

1. **Sign up for racquetpassport.app as both a player and a stringer.** An hour of your time. Map what they've built, what's missing, whether it's actively maintained, and whether they have any recommendation capability. This single action reshapes §2, §16 and possibly your whole positioning — do it before anything else.
2. **Resolve the name** (§16). Trademark search, then a short email to their support address. Don't print anything until this is settled.
3. Export your last 50 jobs into a spreadsheet shaped like §4.1. See what breaks.
4. List 12 stringers to interview. Message 4 today. **Include 2 badminton stringers** — you're not building for them yet, but you need to know what their whiteboard actually looks like.
5. Audit where your racket and string databases came from (§9.3).
6. Write the recommendation engine's tension formula **on paper** using your own bench knowledge, then test it against 20 setups you've strung and know the outcome of. If it disagrees with your own judgement, the formula is wrong — you are the ground truth right now.

---

*End of wireframe v1.1. Revisit §5, §6 and §12 after Phase 0 interviews — those three sections carry the most assumption risk. §16 needs resolving before anything else.*

**Changelog v1.0 → v1.1:** project named Racket Passport; discovered and documented the racquetpassport.app collision (§16, §2, §15); revised badminton strategy for the spec-data gap — passport-layer-only launch with crowdsourced catalogue (§17.3, §3, §11); added sport-aware schema and catalogue-contribution decisions (§18).
