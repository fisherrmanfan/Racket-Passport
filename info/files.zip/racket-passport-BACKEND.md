# Racket Passport — Backend Specification
**Doc:** 3 of 3 · **Version:** v1.0
**Companions:** `racket-passport-MASTER.md` (strategy, pricing, GTM, exit) · `racket-passport-FRONTEND.md` (UI, screens, design)
**Scope:** data model, services, APIs, engines, jobs, security, privacy.

---

## 1. Architecture

Boring on purpose. You are one person with a stringing business to run.

```
        ┌──────────────────────────────────────────┐
        │  Next.js (PWA)  ·  stringer / player /   │
        │                    public passport       │
        └───────────────────┬──────────────────────┘
                            │ HTTPS, typed client
        ┌───────────────────▼──────────────────────┐
        │  API layer — Next.js route handlers      │
        │  authn/authz · validation (shared zod)   │
        └───┬────────┬────────┬────────┬───────────┘
            │        │        │        │
   ┌────────▼──┐ ┌───▼────┐ ┌─▼──────┐ ┌▼────────────┐
   │ Rec       │ │ String │ │ Notify │ │ Label       │
   │ engine    │ │ life   │ │ svc    │ │ render      │
   └────────┬──┘ └───┬────┘ └─┬──────┘ └┬────────────┘
            │        │        │         │
        ┌───▼────────▼────────▼─────────▼───────────┐
        │  Postgres (Supabase/Neon)  +  RLS         │
        └───────────────────────────────────────────┘
              │                    │
        ┌─────▼──────┐      ┌──────▼──────────────┐
        │ Object     │      │ Scheduler           │
        │ store (R2) │      │ (cron / Inngest)    │
        └────────────┘      └──────┬──────────────┘
                                   │
                    ┌──────────────▼────────────────┐
                    │ WhatsApp BSP · SMS · Email    │
                    │ Stripe / HitPay (PayNow)      │
                    └───────────────────────────────┘
```

**Anti-recommendations, stated explicitly:** no microservices, no separate API service, no event bus, no self-built auth, no Kubernetes. Those "services" in the diagram are **modules in one codebase** with clean interfaces. Extract them only when a real constraint forces it.

**Stack:**

| Concern | Choice | Rationale |
|---|---|---|
| DB | Postgres (Supabase or Neon) | RLS gives multi-tenancy nearly free |
| Auth | Supabase Auth / Clerk | Phone OTP + magic link, don't build this |
| Scheduler | Supabase cron or Inngest/Trigger.dev | Retries + idempotency + observability out of the box |
| Messaging | Twilio or 360dialog (WhatsApp BSP), Resend (email) | **Behind your own interface — you will switch on price** |
| Payments | Stripe + HitPay/Stripe PayNow | PayNow is table stakes in SG |
| Files | R2 or S3 | Label PDFs, racket photos |
| Search | Postgres `pg_trgm` + tsvector | Catalogue search does not need Elastic |
| Errors | Sentry | |

---

## 2. Core design decisions

Three decisions shape everything downstream. Get them right now; they're all expensive to retrofit.

### 2.1 `player` is a global identity, not tenant-owned
A player who uses you weekly and a club stringer at tournaments keeps **one** identity and **one** history. This is what makes the product a network rather than a tool — and it's the asset an acquirer actually buys (master doc §17.1).

Cost: consent complexity. A stringer sees a player's jobs **only** where `job.tenant_id = their tenant`, plus whatever the player has explicitly shared. Fails closed.

### 2.2 `racket_instance` ≠ `racket_catalog`
A player owns *this specific Pure Aero* — its own QR short code, its own post-customisation weight, its own grommet age, its own job history. Conflating the model with the physical object kills the entire passport/QR concept.

### 2.3 Sport-aware schema from day one, tennis-only UI
`sport` enum on `racket_catalog`, `string_catalog`, `racket_instance`, `job`. Costs ten minutes now. You lack badminton spec data (master doc §17.3), so badminton launches as passport-only with no recommendations — but the schema must not need a migration when it does.

---

## 3. Data model

```sql
CREATE TYPE sport         AS ENUM ('tennis','badminton','squash','padel');
CREATE TYPE job_status    AS ENUM ('received','queued','strung','ready','collected','cancelled');
CREATE TYPE swing_speed   AS ENUM ('slow','medium','fast');
CREATE TYPE priority      AS ENUM ('control','power','spin','comfort','durability');
CREATE TYPE channel       AS ENUM ('whatsapp','sms','email','push');

-- ─── TENANT ──────────────────────────────────────────
CREATE TABLE tenant (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name          text NOT NULL,
  slug          citext UNIQUE NOT NULL,      -- /s/<slug> public booking page
  country       char(2) NOT NULL,
  currency      char(3) NOT NULL,
  timezone      text NOT NULL,
  plan          text NOT NULL DEFAULT 'free',
  auto_send_reminders boolean NOT NULL DEFAULT false,  -- review-mode for first 30 days
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE tenant_user (
  tenant_id  uuid REFERENCES tenant ON DELETE CASCADE,
  user_id    uuid NOT NULL,                  -- auth provider subject
  role       text NOT NULL CHECK (role IN ('owner','stringer','assistant')),
  PRIMARY KEY (tenant_id, user_id)
);

-- ─── PLAYER (GLOBAL — see §2.1) ──────────────────────
CREATE TABLE player (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid UNIQUE,                 -- NULL until they claim their account
  phone_e164    text UNIQUE,
  email         citext UNIQUE,
  display_name  text NOT NULL,
  ntrp          numeric(2,1),                -- 1.0 – 7.0
  swing         swing_speed,
  play_priority priority,
  hours_per_week numeric(4,1),
  string_breaker boolean DEFAULT false,
  arm_history   boolean DEFAULT false,
  unit_pref     text NOT NULL DEFAULT 'lb',
  reminders_paused boolean NOT NULL DEFAULT false,
  decay_multiplier numeric(4,3) NOT NULL DEFAULT 1.000,  -- LEARNED, see §8.3
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON player (phone_e164);

-- A player↔stringer relationship, with explicit consent scope
CREATE TABLE customer_link (
  tenant_id     uuid REFERENCES tenant ON DELETE CASCADE,
  player_id     uuid REFERENCES player ON DELETE CASCADE,
  share_full_history boolean NOT NULL DEFAULT false,   -- player-controlled
  notes         text,                                   -- tenant-private
  created_at    timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (tenant_id, player_id)
);

-- ─── CATALOGUES (global, shared) ─────────────────────
CREATE TABLE racket_catalog (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sport         sport NOT NULL,
  brand         text NOT NULL,
  model         text NOT NULL,
  year          int,
  -- tennis-rich fields, nullable for other sports
  head_size_sqin  numeric(5,1),
  weight_g        numeric(5,1),
  balance_mm      numeric(5,1),
  swingweight     numeric(5,1),
  stiffness_ra    numeric(4,1),
  length_in       numeric(4,2),
  mains_count     int,
  crosses_count   int,
  tension_min_lb  numeric(4,1),
  tension_max_lb  numeric(4,1),     -- CRITICAL for badminton guardrail (§7.5)
  -- badminton-specific
  weight_class    text,             -- 3U / 4U / 5U
  flex            text,             -- stiff / medium / flexible
  balance_type    text,             -- head-heavy / even / head-light
  source          text NOT NULL,    -- 'seed' | 'contributed' | 'manufacturer'
  verified        boolean NOT NULL DEFAULT false,
  contributed_by_tenant uuid REFERENCES tenant,
  UNIQUE (sport, brand, model, year)
);

CREATE TABLE string_catalog (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sport         sport NOT NULL,
  brand         text NOT NULL,
  model         text NOT NULL,
  family        text NOT NULL,      -- poly | multifilament | synthetic_gut | natural_gut | hybrid_pack
  construction  text,               -- round | shaped | textured | twisted
  gauges_mm     numeric(3,2)[] NOT NULL,
  elasticity    numeric(4,2),       -- YOUR DB
  spin_potential numeric(4,2),      -- YOUR DB
  friction      numeric(4,2),       -- YOUR DB
  tension_hold_class text,          -- excellent | good | fair | poor
  source        text NOT NULL,
  verified      boolean NOT NULL DEFAULT false,
  UNIQUE (sport, brand, model)
);

-- YOUR proprietary grid: performance across tension × swing speed
CREATE TABLE string_perf_grid (
  string_id     uuid REFERENCES string_catalog ON DELETE CASCADE,
  gauge_mm      numeric(3,2) NOT NULL,
  tension_lb    numeric(4,1) NOT NULL,
  swing         swing_speed NOT NULL,
  power_index   numeric(5,2),
  control_index numeric(5,2),
  spin_index    numeric(5,2),
  comfort_index numeric(5,2),
  durability_hr numeric(5,1),       -- feeds the string-life engine (§8)
  PRIMARY KEY (string_id, gauge_mm, tension_lb, swing)
);

-- ─── RACKET INSTANCE (the passport) ──────────────────
CREATE TABLE racket_instance (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  player_id     uuid NOT NULL REFERENCES player ON DELETE CASCADE,
  catalog_id    uuid REFERENCES racket_catalog,
  sport         sport NOT NULL,
  short_code    text UNIQUE NOT NULL,        -- 8-char Crockford base32, QR target
  nickname      text,
  actual_weight_g numeric(5,1),              -- post-customisation
  grip_size     text,
  grommets_changed_at date,
  retired_at    timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ON racket_instance (player_id) WHERE retired_at IS NULL;

-- ─── JOB (the stamp in the passport) ─────────────────
CREATE TABLE job (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id       uuid NOT NULL REFERENCES tenant,
  racket_id       uuid NOT NULL REFERENCES racket_instance,
  player_id       uuid NOT NULL REFERENCES player,     -- denormalised for query speed
  sport           sport NOT NULL,
  strung_by       uuid,                                 -- tenant_user
  status          job_status NOT NULL DEFAULT 'received',

  mains_string_id   uuid REFERENCES string_catalog,
  mains_gauge_mm    numeric(3,2),
  mains_tension_lb  numeric(4,1),            -- CANONICAL UNIT IS LB, ALWAYS
  crosses_string_id uuid REFERENCES string_catalog,
  crosses_gauge_mm  numeric(3,2),
  crosses_tension_lb numeric(4,1),
  prestretch_pct    numeric(4,1) DEFAULT 0,
  two_piece         boolean DEFAULT false,

  received_at     timestamptz NOT NULL DEFAULT now(),
  strung_at       timestamptz,
  ready_at        timestamptz,
  collected_at    timestamptz,

  price_cents     int,
  currency        char(3),
  paid_at         timestamptz,

  -- computed by the string-life engine (§8)
  predicted_hours   numeric(5,1),
  tension_due_at    timestamptz,
  breakage_due_at   timestamptz,
  due_at            timestamptz,             -- min(tension_due, breakage_due)
  engine_version    text,

  recommendation_id uuid,                    -- if this job came from the engine
  notes             text,
  idempotency_key   text UNIQUE              -- client-generated, offline replay (§6.3)
);
CREATE INDEX ON job (tenant_id, status, received_at DESC);
CREATE INDEX ON job (due_at) WHERE status = 'collected';
CREATE INDEX ON job (racket_id, received_at DESC);

-- ─── FEEDBACK (the training label — §7.6) ────────────
CREATE TABLE job_feedback (
  job_id        uuid PRIMARY KEY REFERENCES job ON DELETE CASCADE,
  verdict       text NOT NULL CHECK (verdict IN ('too_stiff','spot_on','too_lively','broke_early')),
  went_dead_after_hours numeric(5,1),
  comment       text,
  created_at    timestamptz NOT NULL DEFAULT now()
);

-- ─── RECOMMENDATION (log every one, accepted or not) ──
CREATE TABLE recommendation (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid REFERENCES tenant,      -- NULL for anonymous public tool
  player_id     uuid REFERENCES player,
  sport         sport NOT NULL,
  inputs        jsonb NOT NULL,              -- full snapshot — inputs change over time
  outputs       jsonb NOT NULL,              -- primary + alternatives + reasoning
  engine_version text NOT NULL,
  outcome       text,                         -- accepted_primary | accepted_alt | ignored
  created_at    timestamptz NOT NULL DEFAULT now()
);

-- ─── NOTIFICATION ────────────────────────────────────
CREATE TABLE notification (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id     uuid REFERENCES tenant,
  player_id     uuid NOT NULL REFERENCES player,
  job_id        uuid REFERENCES job,
  kind          text NOT NULL,               -- ready | due_t7 | due_t0 | feedback | offer
  channel       channel NOT NULL,
  template_id   text,
  scheduled_at  timestamptz NOT NULL,
  sent_at       timestamptz,
  delivered_at  timestamptz,
  clicked_at    timestamptz,
  status        text NOT NULL DEFAULT 'pending',
  idempotency_key text UNIQUE NOT NULL       -- job_id + kind — §9.2
);
CREATE INDEX ON notification (player_id, sent_at DESC);

-- ─── INVENTORY, PRICING (v1.1) ───────────────────────
CREATE TABLE inventory_lot (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenant ON DELETE CASCADE,
  string_id uuid REFERENCES string_catalog,
  gauge_mm numeric(3,2),
  metres_remaining numeric(6,1),
  cost_cents int,
  low_threshold_m numeric(5,1) DEFAULT 20
);

CREATE TABLE price_list_item (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  tenant_id uuid NOT NULL REFERENCES tenant ON DELETE CASCADE,
  label text NOT NULL,
  price_cents int NOT NULL,
  string_id uuid REFERENCES string_catalog,
  is_default boolean DEFAULT false
);
```

### 3.1 The unit rule
**All tensions stored in pounds, `numeric(4,1)`.** Kilogram display is a presentation concern only. Never store a user's display unit alongside the value, never round-trip through kg. This sounds trivial and it is the single most common source of silent data corruption in stringing software.

---

## 4. Multi-tenancy & RLS

Every tenant-scoped table carries `tenant_id` and a policy. Set `app.tenant_id` per request from the validated session; **never** from a client-supplied header.

```sql
ALTER TABLE job ENABLE ROW LEVEL SECURITY;

CREATE POLICY job_tenant_isolation ON job
  USING (tenant_id = current_setting('app.tenant_id', true)::uuid);

-- Players read their own jobs across ALL tenants (§2.1)
CREATE POLICY job_player_read ON job FOR SELECT
  USING (player_id = current_setting('app.player_id', true)::uuid);
```

`player`, `racket_catalog`, `string_catalog`, `string_perf_grid` are global — readable by all authenticated principals, writable only by service role (plus the moderated contribution path, §10).

**Test this adversarially.** Write an integration test suite that, for every tenant-scoped table, asserts tenant A cannot read/update/delete tenant B's row through every exposed endpoint. Run it in CI. A cross-tenant leak in a product whose entire value proposition is "your customer list" is unrecoverable.

---

## 5. Auth

| Principal | Primary | Fallback | Session |
|---|---|---|---|
| Player | WhatsApp OTP | SMS OTP → email magic link | 90d sliding |
| Stringer | Email magic link + optional passkey | SMS OTP | 30d; **re-auth for billing, team changes, data export** |
| Anonymous | none | — | `/r/*` public read, `/find-your-setup` |

**WhatsApp over SMS in SEA:** near-universal, dramatically cheaper at volume, delivery receipts, richer templates.

### 5.1 OTP hardening — non-negotiable
- 6 digits, 5-minute TTL, single-use, **constant-time comparison**
- Store a hash, never the code
- 3 attempts then 15-minute lockout on that identifier
- Rate limits: 5 requests/hour per phone, 20/hour per IP, plus a global circuit breaker
- **Geo-anomaly throttling.** SMS pumping fraud — attackers cycling numbers in high-cost destinations to farm carrier revenue share — is the #1 way a startup gets a five-figure surprise bill from an OTP endpoint. Allowlist your target countries at launch.
- Never reveal whether an identifier exists ("If that number's registered, we've sent a code")

### 5.2 Lead-time items — start these in week 1
- **WhatsApp Business Platform templates need pre-approval.** Your restring reminder is a business-initiated *utility* template. Submit early; approval is not instant, and there's a 24-hour customer-service window rule governing free-form replies.
- **Singapore SMS Sender ID registration (SGNIC / SSIR).** Unregistered alphanumeric sender IDs get labelled "Likely-SCAM" in Singapore. Verify the current requirements and budget the registration.

---

## 6. API surface

REST, versioned at `/api/v1`. OpenAPI spec generated and used to generate the typed frontend client.

```
AUTH
  POST   /auth/otp/request              { identifier, channel }
  POST   /auth/otp/verify               { identifier, code } → session
  POST   /auth/magic-link
  POST   /auth/logout

CATALOGUE (global)
  GET    /catalog/rackets?q=&sport=     typeahead, trigram
  GET    /catalog/rackets/:id
  POST   /catalog/rackets               contribution → pending (§10)
  GET    /catalog/strings?q=&sport=
  POST   /catalog/strings

CUSTOMERS  (tenant-scoped)
  GET    /customers?q=
  POST   /customers                     creates-or-links a global player
  GET    /customers/:playerId
  PATCH  /customers/:playerId

RACKETS
  GET    /rackets/:id
  POST   /rackets                       → mints short_code
  PATCH  /rackets/:id
  GET    /rackets/:id/label?format=     → signed URL (PDF/PNG)

JOBS
  GET    /jobs?status=&q=&cursor=
  POST   /jobs                          Idempotency-Key header REQUIRED
  GET    /jobs/:id
  PATCH  /jobs/:id                      status transitions
  POST   /jobs/:id/repeat               ← "SAME AGAIN". One call, returns new job.

DUE / REMINDERS
  GET    /due?window=7d
  POST   /due/send                      { jobIds[] } bulk approve
  POST   /due/:jobId/skip

RECOMMEND
  POST   /recommend                     works UNAUTHENTICATED (public tool)
  POST   /recommend/:id/outcome         { outcome }

FEEDBACK
  POST   /jobs/:id/feedback             tokenised link, no login required

PUBLIC
  GET    /public/r/:shortCode           scope varies by session (§11.2)
  POST   /public/r/:shortCode/claim

PLAYER
  GET    /me/rackets
  PATCH  /me/preferences
  POST   /me/pause-reminders
  GET    /me/export                     PDPA — build in v1 (§13)
  DELETE /me                            PDPA — soft delete + 30d purge

WEBHOOKS (inbound)
  POST   /hooks/whatsapp                delivery receipts, inbound replies (STOP)
  POST   /hooks/stripe
```

### 6.1 `POST /jobs/:id/repeat` deserves its own endpoint
The repeat path is the majority of all traffic and the frontend's most important interaction (frontend doc §4.2). Making it one round trip — copy setup, recompute due dates against current player state, mint label, return — is what buys the sub-5-second target. Don't make the client assemble it.

### 6.2 Errors
```json
{ "error": { "code": "TENSION_ABOVE_FRAME_MAX",
             "message": "This frame is rated to 24 lb.",
             "field": "mains_tension_lb",
             "severity": "warning" } }
```
`severity: warning` is **advisory, non-blocking** — the client shows a dismissible notice (frontend doc §4.4). The stringer is the expert; a blocking validation on a bench tool gets the tool abandoned.

### 6.3 Idempotency
`POST /jobs` requires an `Idempotency-Key` header, client-generated. Store it on `job.idempotency_key` with a unique constraint; a replay returns the original 200 with the original body. This is what makes the frontend's offline queue (frontend doc §8) safe to replay blindly.

---

## 7. Recommendation engine — **integration, not construction**

> **Status: you already own this.** The engine exists. This section is therefore an *integration contract* plus a mock, not a build spec. The goal is that swapping the mock for your real engine is a one-line change in a factory function, made whenever you're ready — not a refactor.

### 7.0 Integration strategy

**Define the port now, build everything against a mock, integrate later.**

```ts
// lib/recommendation/port.ts — the ONLY thing the rest of the codebase knows about
export interface RecommendationEngine {
  version(): string;
  supports(sport: Sport): boolean;
  recommend(input: RecommendInput): Promise<RecommendOutput>;
}

// lib/recommendation/index.ts
export const engine: RecommendationEngine =
  process.env.REC_ENGINE === 'real'
    ? createRealEngine({ endpoint: process.env.REC_ENGINE_URL })   // ← your engine
    : createMockEngine({ seed: 'racket-passport' });
```

**Anti-corruption layer is mandatory.** Your existing engine has its own input shape, its own units, probably its own racket/string identifiers. `createRealEngine` is where that gets translated into `RecommendInput`/`RecommendOutput` — and nowhere else. If your engine's field names leak into API handlers or React components, you've coupled the whole product to one implementation and lost the ability to version it independently.

Whatever form the engine currently takes — a Python module, a notebook, a spreadsheet of coefficients, a service — the adapter absorbs it. A subprocess call and an HTTP call are equally fine behind this interface. Don't rewrite the engine to fit the app; write 60 lines of adapter.

### 7.1 What stays on the app side regardless

These are **not** the engine's job, and they shouldn't move inside it:

| Concern | Why it stays here |
|---|---|
| `recommendation` table logging | Every recommendation, accepted or not, is a datapoint for the moat (master doc §17.1). The engine is stateless; the app owns memory. |
| `engine_version` stamping | You need to attribute outcome changes to engine changes. Get the version from `engine.version()` and store it on every row. |
| Outcome attribution | Did the stringer accept the primary, an alternative, or ignore it? Pure app-side signal. |
| Guardrail enforcement (§7.4) | Defence in depth. Even if the engine already enforces these, re-check at the API boundary. A frame-max violation reaching the database is unrecoverable. |
| Feedback capture (§7.6) | Feeds back into the engine's future calibration, but lives in your schema. |
| Rate limiting / abuse control | Public unauthenticated tool. |

### 7.2 Contract
```ts
type RecommendInput = {
  sport: Sport;
  racketCatalogId?: string;
  racketSpecs?: Partial<RacketSpecs>;   // manual entry fallback
  ntrp?: number;
  swing: SwingSpeed;
  priority: Priority;
  stringBreaker: boolean;
  armHistory: boolean;
  hoursPerWeek?: number;
  climate?: 'temperate' | 'hot_humid';  // SG default: hot_humid
  budgetBand?: 'value' | 'mid' | 'premium';
};

type RecommendOutput = {
  primary: Setup & { confidence: number; expectedPlayableHours: number };
  alternatives: [Setup & {label:'Easier on the arm'}, Setup & {label:'Lasts longer'}];
  reasoning: string[];      // human-readable, ordered by weight
  warnings: string[];
  engineVersion: string;
};
```

**Always return three options.** The pick, a comfort variant, a durability variant. Choice reduces the feeling of being dictated to, and clicks on alternatives are free preference signal.

### 7.3 Contract gaps to check against your existing engine

Three fields in `RecommendOutput` are load-bearing for the *rest* of the product. If your engine doesn't already emit them, that's not a problem with your engine — it's work the adapter has to cover. Worth checking early, because two of them have downstream dependencies.

| Field | Depended on by | If your engine doesn't emit it |
|---|---|---|
| `reasoning: string[]` | **Frontend doc §4.3.** The "why this" list is the differentiating UI — a bare number is what every competitor shows. | Generate the strings in the adapter from the input+output delta (e.g. compare emitted tension against the frame's mid-range and describe the gap). Lower fidelity than the engine's own reasoning, but far better than nothing. |
| `expectedPlayableHours` | **§8, the string-life engine** — the entire due-date and reminder loop | Derive independently from `string_perf_grid.durability_hr` (§8.1). This is the fallback design and it works; it just won't benefit from whatever your engine knows. |
| `alternatives` (comfort + durability variants) | Frontend result screen; alternative-clicks are free preference signal | Adapter can call the engine twice more with `priority` overridden to `comfort` and `durability`. Cheap, and arguably more honest than synthesising them. |

`confidence` is nice-to-have — if absent, the adapter can return `null` and the UI simply omits the "we'll tune it after feedback" degradation path.

**Units and identifiers at the boundary:** confirm whether your engine speaks pounds or kilograms, millimetres or US gauge numbers, and whether it identifies rackets/strings by your own IDs or by brand+model strings. All conversion happens in the adapter. The canonical unit in the database is pounds, always (§3.1).

### 7.4 Hard guardrails (override scoring, always)
1. Never full poly above 26 lb for a player with declared arm history.
2. Never poly at all for NTRP < 3.5 with slow swing — they cannot compress it. Recommend multi/synthetic gut **and say why in the reasoning**.
3. Never exceed `tension_max_lb`.
4. Confidence < 0.5 → degrade gracefully: *"here's a safe starting point, we'll tune it after your feedback."*

### 7.4b The mock — build this properly, it earns its keep

The mock isn't throwaway scaffolding. It's the thing you demo to design partners, the thing E2E tests run against, and the thing that lets frontend work proceed without your engine in the loop.

**Requirements:**
1. **Deterministic.** Seeded, pure function of input. Same input → same output, forever. Non-deterministic mocks produce flaky E2E tests and you will waste days on it.
2. **Plausible, not random.** A crude version of §7.3's shape — mid-tension from the frame, nudged by swing and priority — is enough. It should never emit something a stringer would laugh at, because you'll be showing this screen to stringers in Phase 0 interviews.
3. **Respects the guardrails** (§7.4) so the warning UI can be built and tested against it.
4. **Emits reasoning strings**, so the frontend's `<ReasoningList>` has real content to lay out.
5. **Configurable failure modes** — `?mock=timeout`, `?mock=low_confidence`, `?mock=unsupported_sport` — so error and degraded states get designed rather than discovered in production.
6. Reports `version()` as `mock-0.1.0`, so mock-generated rows are trivially filterable out of your dataset later. **This matters**: mock recommendations must never contaminate the training data that is your exit asset.

```ts
// Rows written by the mock are tagged and excluded from any export
WHERE engine_version NOT LIKE 'mock-%'
```

### 7.5 Badminton: guardrail only, no prescription
No spec data → **`POST /recommend` returns `501 SPORT_NOT_SUPPORTED` for badminton.** The frontend hides the entry points entirely (frontend doc §4.3).

The one badminton advisory you *can* ship needs a single number per model — `tension_max_lb`, which is published and printed on the frame:
```
POST /jobs  with sport=badminton and mains_tension_lb > racket.tension_max_lb
  → 200 OK, with warning TENSION_ABOVE_FRAME_MAX
```
Over-tensioning is badminton's dominant failure mode and it cracks frames. Cheap to build, genuinely useful, and it gives stringers a reason to start populating the badminton catalogue (§10).

### 7.6 The feedback loop
72h after `collected`, send one message with three taps: *too stiff / spot on / too lively*, plus optional "when did it start feeling dead?".

That single interaction yields: a labelled datapoint, a per-player `decay_multiplier` correction (§8.3), a non-salesy retention touchpoint, and a stringer who looks like they followed up.

**Target >35% response rate.** Under 20% means the message is wrong, not the idea.

---

## 8. String-life engine (the retention core)

The folk rule — *"restring as many times per year as you play per week"* — ignores string type entirely. Do better.

### 8.1 Model
```
playable_hours = base_hours(family, gauge)          -- from string_perf_grid.durability_hr
               × ntrp_factor
               × swing_factor
               × tension_factor                      -- higher tension → shorter life
               × player.decay_multiplier             -- LEARNED
               × climate_factor                      -- sustained heat accelerates poly relaxation

tension_due_at  = strung_at + playable_hours / hours_per_week
breakage_due_at = only for string_breaker players, from observed breakage history
due_at          = LEAST(tension_due_at, breakage_due_at)
```

Rough family ordering on tension retention (calibrate yourself): polyester < synthetic gut < multifilament < natural gut. The ordering **flips** for breakage with big hitters. Poly's dominant failure mode is going dead, not snapping — which is exactly why most players restring far too late, and exactly why this feature has value.

### 8.2 Two due dates, messaged differently
`tension_due` → *"your strings have gone dead"*. `breakage_due` → *"you're due to snap"*. Different urgency, different copy, different conversion. Don't collapse them.

### 8.3 Adaptive correction
On each new job for a racket, compare the actual interval to the prediction and nudge that player's `decay_multiplier` (bounded, e.g. `[0.6, 1.6]`, damped so one anomaly doesn't swing it). After ~3 jobs the prediction should be meaningfully personal.

**Surface accuracy to the stringer** — *"prediction accuracy for your customers: 81%"* is a retention feature for the subscription itself.

### 8.4 Recompute triggers
Nightly sweep, plus on: new job, feedback received, player changes `hours_per_week`. Never recompute a collected job's `due_at` after a reminder has been sent for it — moving the goalposts under a scheduled message causes duplicate sends.

---

## 9. Notification service

### 9.1 Daily sweep
```
for jobs where status='collected' and due_at in {today+7, today}:
  skip if player.reminders_paused
  skip if notification exists for (job_id, kind)                  -- idempotency
  skip if player received ≥2 messages in trailing 7d              -- GLOBAL cap
  skip if tenant plan message quota exhausted
  create notification(scheduled_at, idempotency_key = job_id||kind)
  if tenant.auto_send_reminders → enqueue send
  else → surface in GET /due for review
```

### 9.2 Rules that are not optional
- **Idempotency key on every notification.** Double-texting a customer about their racket is the fastest route to a cancelled subscription.
- **Two messages per cycle, maximum.** T−7, T+0, then stop. One T+21 follow-up only if an offer is attached.
- **Global per-player frequency cap, enforced in the service, not in calling code.** A player using three stringers must not receive three reminders in a week. This dedupe is only possible *because* `player` is global (§2.1) — it's a concrete payoff of that decision.
- Every message carries one-tap **book** and one-tap **snooze 30 days**.
- Inbound `STOP` on any channel → `reminders_paused = true` immediately, honoured across all tenants.

### 9.3 Channel ladder
`whatsapp → sms → email`. Fall through on hard failure only, never on slow delivery. Record `sent/delivered/clicked` per attempt.

### 9.4 Provider abstraction
```ts
interface MessageProvider {
  send(msg: OutboundMessage): Promise<{ providerId: string }>;
  supports(channel: Channel, country: string): boolean;
}
```
You *will* switch providers on price as volume grows. Messaging is real COGS and margin depends on it (master doc §12.1). Never let provider SDK types leak into your domain code.

### 9.5 Attribution
When a reminder link converts to a booking, write it back to the notification (`clicked_at`) and to the resulting job. **Reminder → booking conversion is the metric the entire business rests on** (master doc §14). If it's under 15%, no other feature matters.

---

## 10. Catalogue contribution & moderation

Your tennis catalogue is seeded from your own databases. Badminton starts near-empty and gets built by users.

```
POST /catalog/rackets  →  status='pending', source='contributed'
                       →  immediately usable BY THE CONTRIBUTING TENANT
                       →  invisible to others until verified
```

**Contributor sees their record instantly.** Blocking a stringer mid-job on a moderation queue is unacceptable — the racket is on the machine.

Merge/dedupe: fuzzy match on `(sport, brand, model)` via trigram; flag near-duplicates for review; keep a `merged_into` pointer so historic jobs never break.

**Budget real time for manual moderation on the first few thousand records.** This is unglamorous and it's how the moat gets built: at ~5,000 logged badminton jobs with feedback attached, you can build a badminton engine from *observed outcomes* rather than published specs — a strictly better dataset than anything a competitor can license (master doc §17.3).

**Test the moderation workflow on tennis first**, where you can spot a bad record instantly.

---

## 11. QR, short codes, labels

### 11.1 Short codes
- Crockford base32, 8 chars, excludes I/L/O/U (ambiguity + accidental profanity)
- Minted at `racket_instance` creation, **permanent for the racket's life**
- Collision check on insert with retry
- Encode `https://<domain>/r/<code>` and nothing else — **never PII, never a JSON blob**. The sticker outlives the data.

### 11.2 Scope resolution on `GET /public/r/:code`
```
anonymous       → racket model, current setup, strung date, status, stringer name, book CTA
                  NO owner name, NO phone, NO history
owning player   → full history, feedback prompts, request restring
stringer of job → edit + "same again" shortcut
other stringer  → anonymous view
```
Fails closed. This is a public unauthenticated endpoint on a guessable-ish URL — rate limit it and never widen the anonymous scope.

### 11.3 Label rendering
Server-side, deterministic, reproducible from a job ID. PDF (vector) + PNG (300dpi) → object store, served via short-lived signed URL.

Presets: Dymo 99012 (89×36mm), Brother QL 62mm continuous, **Niimbot D11 (40×30mm — the home-stringer default, prioritise it)**, A4 24-up sheet.

QR: error correction M, quiet zone ≥4 modules, min 15mm printed.

---

## 12. Billing & entitlements

Plans and limits live in **one config module**, not scattered through the code:
```ts
const PLANS = {
  free:  { jobsPerMonth: 15, customers: 30, messages: 20,  recommendations: 5,
           autoReminders: false, users: 1, venues: 1 },
  solo:  { jobsPerMonth: Infinity, customers: Infinity, messages: 250,
           recommendations: Infinity, autoReminders: true, users: 1, venues: 1 },
  shop:  { ..., messages: 1000, users: 5, venues: 3 },
  club:  { ..., messages: 5000, users: Infinity, venues: Infinity },
};
```

**Limit behaviour matters more than the limits.** When a free tenant hits 15 jobs: they can still log the job — you never block a stringer mid-work — but reminders pause and an upgrade prompt appears. Blocking the core action of a bench tool to force an upgrade destroys the relationship with exactly the persona you need as distribution.

Message quotas are metered separately with top-up packs; messaging is your only meaningful variable cost.

---

## 13. Privacy, PDPA, data rights

**These are exit blockers, not compliance chores.** Retrofitting them after 50k jobs is impossible, and data rights are precisely what an acquirer diligences (master doc §17.1).

- **Singapore PDPA:** consent for marketing, purpose limitation, access and correction rights, and a **Do Not Call registry obligation** for marketing to telephone numbers. A reminder about a service the player purchased is arguably transactional rather than marketing — **the whole product hinges on this distinction, so get it checked by someone qualified.** I'm not a lawyer.
- **ToS from day one** must grant you licence to use anonymised, aggregated job data for model improvement, while the stringer retains their customer relationships. This clause is the exit asset.
- `GET /me/export` and `DELETE /me` (soft delete + 30-day purge) built in v1. Two hours now, two weeks later.
- **Audit the provenance of your racket and string databases.** If any of it was scraped from a manufacturer or retailer, that surfaces in acquisition diligence as a commercial-use problem. Measured-in-house data is the strongest position.
- PII encrypted at rest; phone numbers stored E.164; no PII in logs, URLs, or QR payloads.

---

## 14. Background jobs

| Job | Schedule | Notes |
|---|---|---|
| `due-sweep` | daily 08:00 tenant-local | §9.1 |
| `send-queue` | every 5 min | retry with backoff, dead-letter after 3 |
| `feedback-request` | hourly | 72h after `collected` |
| `decay-recalc` | nightly | §8.3 |
| `low-stock-check` | daily | |
| `catalogue-dedupe` | weekly | flags for human review, never auto-merges |
| `purge-deleted` | daily | 30d after soft delete |
| `metrics-rollup` | hourly | powers the analytics screens |

All jobs idempotent, all keyed, all observable. Tenant-local scheduling matters — a Singapore stringer's customers should not get a 3am reminder.

---

## 15. Observability

**SLOs:** API p95 < 300ms · `POST /jobs` p95 < 500ms · `/r/:code` p95 < 200ms · notification send success > 98% · uptime 99.5%.

**Alert on (page-worthy):** notification queue depth, send failure rate, OTP request spike (fraud), any cross-tenant RLS denial, payment webhook failures.

**Business metrics as first-class telemetry** — reminder→booking conversion, prediction accuracy, feedback response rate. These belong on the same dashboard as latency, because they're what tells you whether the product works.

---

## 16. Testing

| Layer | Coverage |
|---|---|
| Unit | Recommendation engine — **golden-file tests against setups you've personally strung and know the outcome of.** This is your regression suite and your calibration harness. |
| Unit | String-life engine, unit conversion, short-code generation |
| Integration | **RLS adversarial suite** (§4) — mandatory in CI |
| Integration | Idempotency: replay every mutating endpoint, assert single effect |
| Integration | Notification caps — assert a player linked to 3 tenants gets ≤2 messages/week |
| E2E | Scan → repeat job → label, under 5s |
| E2E | Anonymous passport leaks no PII |
| Load | Tournament burst: 200 jobs in an hour, one tenant |

---

## 17. Backend build order

| Phase | Weeks | Ship |
|---|---|---|
| **B0** | 1–2 | Schema, RLS + adversarial tests, auth, tenant bootstrap, catalogue import + normalisation of your two databases |
| **B1** | 3–5 | Customers, rackets (+ short codes), jobs CRUD, `/repeat`, idempotency |
| **B2** | 6–7 | Label rendering, `/public/r/:code` scope resolution |
| **B3** | 8 | Recommendation **port + mock** (§7.0, §7.4b), `recommendation` logging, guardrail enforcement, outcome attribution. ~1 week, not 2 — the engine exists. |
| **B4** | 9–10 | String-life engine, due sweep, notification service, WhatsApp integration, feedback loop |
| **B5** | 11–12 | Quotas/entitlements, exports, deletion, observability |
| **B6** | 13+ | Inventory, invoicing/payments, analytics rollups, contribution moderation |
| **B-int** | *whenever ready* | **Swap mock → real engine.** One env var + the adapter. Should be a day's work if §7.0 was respected. Deliberately unscheduled — it's not on the critical path, which is the point. |

**Net effect of already owning the engine: roughly a week off the critical path, and the whole project de-risked** — the hardest, most domain-specific component is the one you're not building under time pressure. Spend the saved week on the string bed meter and the reminder loop instead; those are what the business actually rests on.

**Week-1 parallel tasks with external lead times — start immediately:** WhatsApp template approval, SG Sender ID registration, database provenance audit.

---

## 18. Open backend questions

1. **Supabase vs Neon + Clerk?** Supabase bundles auth + RLS + cron and is faster to ship; Neon+Clerk is more flexible later. Leaning Supabase for the speed, given you're solo.
2. **Should the public recommendation tool write to `recommendation` for anonymous users?** Yes for the data, but it needs abuse rate-limiting. Cookie-based pseudonymous ID, no PII.
3. **How is `hours_per_week` obtained?** Self-reported at signup is the only realistic v1 answer, and it's the biggest error term in the string-life model. Consider inferring it from actual restring intervals after job 3 and quietly correcting.
4. **Tenant-local vs UTC scheduling** — tenant-local is right, but confirm before building the sweep; changing it later means re-keying every scheduled notification.
5. **What shape is your existing engine?** In-process module, subprocess, HTTP service, or a coefficient table you'd port? Determines whether `createRealEngine` is a function call, a `child_process`, or a fetch — and whether latency budgets (§15) need adjusting. All four are fine; the adapter absorbs it.
5b. **Does your engine emit reasoning strings and expected string life?** See §7.3 — these two have downstream dependencies (the UI and the entire reminder loop respectively). Worth answering before B3 rather than during B-int.
5c. **Do you version the recommendation engine per tenant?** Probably not, but log `engine_version` on every output so you can attribute outcome changes to engine changes — and so mock rows stay filterable.
6. **Does a player linked to multiple tenants get one `decay_multiplier` or one per tenant?** One global — string decay is a property of the player's game, not the stringer. Confirm this holds when you have data.
