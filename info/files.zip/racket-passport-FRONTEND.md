# Racket Passport — Frontend Specification
**Doc:** 2 of 3 · **Version:** v1.0
**Companions:** `racket-passport-MASTER.md` (strategy, pricing, GTM, exit) · `racket-passport-BACKEND.md` (data, services, APIs)
**Scope:** everything the user sees and touches. Client architecture, design system, screens, interactions, offline behaviour, accessibility.

> Naming caveat carried from the master doc §16: "Racket Passport" is an internal codename until the trademark collision with `racquetpassport.app` is resolved. Don't hardcode the brand string — put it in one config export so a rename is a one-line change.

---

## 1. Platform decision

**PWA first. Installable. One codebase.**

| | Decision |
|---|---|
| Framework | Next.js (App Router), React, TypeScript strict |
| Delivery | Installable PWA — `manifest.json`, service worker, add-to-home-screen prompt after 3rd session |
| Native | Deferred to Phase 4+, via Expo, only once retention is proven |
| Targets | Stringer: iPad + Android tablet + desktop. Player: phone. Public scan page: any phone, including old ones. |

**Why not native at launch:** app-store review latency kills the iteration speed you need in months 1–6, you'd be maintaining three codebases as a solo builder, and the two features people assume need native (camera QR scanning, push) both work in a modern PWA. `BarcodeDetector` where available, `jsQR`/`zxing-wasm` fallback on a `getUserMedia` stream.

**The one real PWA cost:** iOS web push requires the user to install the PWA to the home screen first, and it's less reliable than APNs. Mitigate by treating **WhatsApp as the primary notification channel** (which you're doing anyway — see backend doc §9) and web push as a convenience layer only. Never make a critical flow depend on web push.

### 1.1 Three distinct surfaces, one app
```
/app/*      Stringer console   — tablet-first, dense, high contrast, gloved/dirty hands
/my/*       Player portal      — phone-first, calm, low density, emotional
/r/*        Public passport    — anonymous, fast, one job: "is my racket ready + what's in it"
```
These have genuinely different design needs. Don't force one visual density across all three.

---

## 2. Design direction

### 2.1 Grounding
The subject's world is a **workshop bench**: a string bed under tension, a calibrated tension head, reels of fluoro poly, a thermal label printer, a stamped logbook. The stringer console is used standing up, under bright light, with dirty hands, often in a hurry. The player portal is used on a sofa. The design should come from that world, not from a generic SaaS dashboard.

**Explicitly rejected:** the cream-background / high-contrast-serif / terracotta-accent look. It's the current default for every AI-adjacent product page and it says nothing about tension, precision, or workshops.

### 2.2 Tokens

```css
/* Base — graphite, from the bench and the frame */
--ink-900:  #14161A;   /* stringer console background */
--ink-700:  #1E2228;   /* raised surfaces, cards */
--ink-500:  #2C323B;   /* borders, dividers */
--ink-300:  #6B7480;   /* secondary text on dark */
--paper:    #F7F8F7;   /* player portal + public page background */
--paper-2:  #E8EBE8;   /* player portal card fill */

/* Signal — fluoro poly. Authentic to the subject: this is
   literally the colour of half the string on the market. */
--fluoro:   #D6FF3D;   /* primary action, live/active state */
--fluoro-d: #A8C92E;   /* fluoro on light backgrounds, hover */

/* Status */
--fresh:    #4ADE80;   /* strings healthy */
--fading:   #FACC15;   /* due soon */
--dead:     #F87171;   /* overdue / snapped */
--gut:      #E9DCC3;   /* natural gut cream — used ONLY for the gut string family */
```

Rule: **`--fluoro` is the only accent.** One action colour, used sparingly, so that "the bright thing is the thing to press" is learnable in one session. Status colours never appear on buttons.

### 2.3 Typography

| Role | Face | Use |
|---|---|---|
| Display | A tight industrial/condensed grotesque (e.g. *Archivo Condensed*, *Oswald*) | Screen titles, the tension numerals on the passport page. Used with restraint. |
| Body/UI | A neutral workhorse grotesque (e.g. *Inter*) | Everything else |
| Data | A mono (e.g. *JetBrains Mono*) | **Tensions, gauges, short codes, dates on labels.** `24 / 22` must never be mistaken for prose. |

The mono for numerics is not decoration — it's the same reason a multimeter uses one. Tension, gauge and short-code are the values people transcribe, verify and read aloud across a workshop. Give them tabular figures and a fixed width.

### 2.4 Signature element — the string bed meter

The one thing this product is remembered for. It replaces a generic progress bar with **an actual string bed**, drawn as SVG mains and crosses matching the racket's real pattern (16×19, 18×20, badminton 22×23):

- **Fresh:** strings drawn taut, full opacity, tight even spacing, `--fresh`
- **Fading:** spacing subtly loosens, opacity drops, colour shifts toward `--fading`
- **Dead:** visibly slack, sagging bezier curves, `--dead`
- **Snapped:** two mains drawn broken

It appears at three sizes: 24px (list row), 96px (racket card), 240px (passport hero). Same component, one `size` prop.

This is the whole retention mechanic in one graphic — it makes an invisible, gradual degradation *visible*, which is exactly why players restring too late. Build this properly; it earns more than any feature in the roadmap.

> Motion: the meter animates **once** on mount, over ~600ms, from taut to its true state. Nowhere else in the app animates beyond 150ms state transitions. Respect `prefers-reduced-motion` — skip straight to final state.

### 2.5 Copy voice
Plain, specific, unfussy — how a good stringer talks to a regular.

| Don't | Do |
|---|---|
| "Submit" | "Save & print label" |
| "Your string job has been successfully created" | "Logged. Label ready." |
| "An error occurred" | "Couldn't save — you're offline. It'll go up when you reconnect." |
| "No data available" | "No jobs yet. Log your first one — takes about 20 seconds." |
| "Restring recommendation generated" | "Here's what I'd string" |

Actions keep their name through the whole flow: the button says "Mark strung", the toast says "Marked strung", the log entry says "Strung".

---

## 3. Route map

```
PUBLIC
  /                          Marketing home
  /find-your-setup           ← FREE recommendation tool, no auth. The SEO + viral front door.
  /r/[shortCode]             Public passport page (QR destination)
  /s/[stringerSlug]          Stringer's public booking page
  /login                     Passwordless entry (phone or email)

STRINGER  /app
  /app                       Today
  /app/jobs                  All jobs · filters, search
  /app/jobs/new              New job flow
  /app/jobs/[id]             Job detail / edit
  /app/due                   Due-this-week review queue
  /app/customers             Customer list
  /app/customers/[id]        Customer + their rackets + history
  /app/rackets/[id]          Racket instance · passport · label
  /app/inventory             Reels, stock, low-stock alerts
  /app/recommend             Recommendation tool (stringer-facing)
  /app/analytics             Revenue, volume, retention
  /app/settings/*            Profile, price list, labels, messaging, billing, team

PLAYER  /my
  /my                        My rackets
  /my/rackets/[id]           Passport · history · feedback
  /my/setups                 Saved recommendations
  /my/stringers              Linked stringers, sharing consent
  /my/settings               Reminders, channel, units, pause-all, export, delete
```

**Route-level rule:** `/r/*` must render server-side and be usable on a cold 3G connection with JS disabled beyond hydration. It's the surface a stranger hits from a sticker, and it's your top-of-funnel.

---

## 4. Screens

### 4.1 Stringer — Today (`/app`)
```
┌──────────────────────────────────────────────────┐
│  Today                            [ + New job ]  │
├──────────────────────────────────────────────────┤
│   IN QUEUE 3    READY 2    DUE THIS WEEK 7       │
├──────────────────────────────────────────────────┤
│  ⚡ 7 customers due                    [Review →]│
│     5 auto-send Wed 9am · 2 need a decision      │
├──────────────────────────────────────────────────┤
│  QUEUE                                           │
│  ▨▨▨  Alex Tan · Pure Aero 98                    │
│       RPM Blast 1.25  24/22   in 2h  [Mark strung]│
│  ▨▨▨  Wei Ming · Ezone 100                       │
│       Hybrid  23/21          in 5h   [ → ]       │
├──────────────────────────────────────────────────┤
│  READY FOR PICKUP                                │
│  ▨▨▨  Sarah L. · Blade 98    notified 1d ago     │
├──────────────────────────────────────────────────┤
│  ⚠ RPM Blast 1.25 — 12m left (≈1 job)            │
└──────────────────────────────────────────────────┘
```
`▨▨▨` = string bed meter at 24px.

Touch targets ≥48px throughout. This screen is used standing at a bench.

### 4.2 Stringer — New job (the 20-second flow)

**This is the most important flow in the product.** Most jobs are repeats. Optimise brutally for the repeat case and let the new-customer case be slower.

```
① IDENTIFY
   [ 📷 Scan racket QR ]        ← fastest path, camera opens immediately
   [ Search customer or phone ] ← typeahead, 2 chars minimum
   [ + New customer ]

   Scan → known racket → JUMP STRAIGHT TO ③ pre-filled.

② SELECT (only if not scanned)
   Customer  Alex Tan          ▾
   Racket    Pure Aero 98      ▾   [+ add racket]

③ SETUP
   ┌ LAST TIME ─────────────────────────────┐
   │ ▨▨▨  RPM Blast 1.25 · 24/22 · 04 Mar   │
   │      Feedback: 👍 spot on               │
   │      ┌───────────────────────────────┐ │
   │      │      S A M E   A G A I N      │ │  ← the money button
   │      └───────────────────────────────┘ │
   └────────────────────────────────────────┘
   [ ✨ Get a recommendation ]  [ Enter manually ]

④ CONFIRM
   Price  S$ 35        (from price list, editable)
   Ready  Thu 6pm      ▾
   [✓] Text customer when ready
   ┌──────────────────────────────────────┐
   │  Save & print label                  │
   └──────────────────────────────────────┘
```

**Performance requirement:** scan → saved job in **under 5 seconds** on the repeat path, including label generation. Pre-fetch the customer's last job on scan; optimistically render the confirm step while the write is in flight.

### 4.3 Recommendation wizard (`/find-your-setup`, `/app/recommend`)

Four steps, one question per screen on mobile, all four visible on tablet. No account required until "Save".

```
┌────────────────────────────────────────┐
│  ●●●○   Step 3 of 4                    │
│                                        │
│  How fast do you swing?                │
│                                        │
│  ┌──────────┐┌──────────┐┌──────────┐  │
│  │  SLOW    ││  MEDIUM  ││   FAST   │  │
│  │ compact, ││ full but ││ full,    │  │
│  │ controlled││ measured ││ fast     │  │
│  └──────────┘└──────────┘└──────────┘  │
│                                        │
│  Not sure? Pick medium — we'll tune it │
│  after your first restring.            │
│                                        │
│                          [ Back ] [ → ]│
└────────────────────────────────────────┘
```

> **Engine note:** the recommendation engine already exists as a separate component (backend doc §7). The frontend never talks to it directly — it calls `POST /recommend` and gets the same `RecommendOutput` shape whether a mock or the real engine is behind it. **Build every one of these screens against the mock.** Nothing on this page should need to change at integration time; if it does, the boundary was drawn wrong.

**Result screen — the reasoning is the product.** Never show a bare number.

```
┌──────────────────────────────────────────┐
│           ╱▨▨▨▨▨▨▨▨╲                     │  ← string bed hero, 240px
│          │ ▨▨▨▨▨▨▨▨ │                    │
│           ╲▨▨▨▨▨▨▨▨╱                     │
│                                          │
│   RPM Blast 1.25mm                       │
│   ┌────────┐   ┌────────┐                │
│   │ 24 lb  │   │ 22 lb  │                │  ← mono, large
│   │ mains  │   │ crosses│                │
│   └────────┘   └────────┘                │
│                                          │
│   Should last about 22 hours             │
│   ≈ 5 weeks at 4 hrs/week                │
│                                          │
│   WHY THIS                          ▾    │
│   · 98 sq in, 16×19 → near mid tension   │
│   · Fast swing + control → +2 lb         │
│   · You break strings → 1.25, not 1.20   │
│   · RA 67 is a firm frame → stayed off 26│
│                                          │
│   ALSO CONSIDER                          │
│   ○ Easier on the arm  · poly/multi      │
│   ○ Lasts longer       · 1.30 shaped     │
│                                          │
│   [ Use this ]      [ Save to profile ]  │
└──────────────────────────────────────────┘
```

Clicks on "Also consider" are a free preference signal — instrument them (§13).

**Sport gating:** if `sport = badminton`, the recommendation entry points are **hidden, not disabled**. No spec data, no advice (master doc §17.3). A greyed-out button invites a support ticket; an absent one doesn't. The only badminton advisory surface is the max-tension warning in §4.4.

### 4.4 Manual setup entry — with guardrails
```
  Mains    [ RPM Blast          ▾ ] [1.25 ▾] [ 24 ] lb
  Crosses  [ same as mains      ▾ ] [1.25 ▾] [ 22 ] lb
           [ ] Pre-stretch  [ ] Two-piece

  ⚠ This frame is rated to 24 lb. You've entered 28.
     [ I know — proceed ]                        ← badminton, and it must be dismissible
```
Warnings are **advisory and dismissible**, never blocking. The stringer is the expert; the software is a second pair of eyes. A blocking validation on a bench tool gets the tool abandoned.

### 4.5 Player — My rackets (`/my`)
```
┌────────────────────────────────────┐
│  My rackets                        │
│                                    │
│  ┌──────────────────────────────┐  │
│  │      ╱▨▨▨▨▨╲                 │  │
│  │     │ ▨▨▨▨▨ │      73%       │  │
│  │      ╲▨▨▨▨▨╱                 │  │
│  │  Pure Aero 98                │  │
│  │  RPM Blast 1.25 · 24/22      │  │
│  │  Strung 04 Mar · due ~18 May │  │
│  │  [ Request restring ]        │  │
│  └──────────────────────────────┘  │
│  ┌──────────────────────────────┐  │
│  │      ╱▨ ▨  ▨╲                │  │
│  │     │ ▨  ▨▨ │   ⚠ 12d over  │  │  ← visibly slack
│  │  Blade 98                    │  │
│  └──────────────────────────────┘  │
│                                    │
│  [ ✨ Find a new setup ]           │
│  Reminders: WhatsApp ▾  [ Pause ]  │
└────────────────────────────────────┘
```

**"Pause all reminders" must be reachable in one tap from the player's home screen and from every message footer.** Not buried in settings. The product's entire risk profile is notification fatigue (master doc §15) and the cheapest insurance is making opt-out trivially easy — people who can leave freely don't leave.

### 4.6 Public passport (`/r/[shortCode]`) — three states, one URL

Resolves by session, server-side.

**Anonymous** — no PII. Never render the owner's name or phone.
```
        [ shop logo ]
     Babolat Pure Aero 98
   ───────────────────────────
     ╱▨▨▨▨▨▨╲
    │ ▨▨▨▨▨▨ │      Ready ✅
     ╲▨▨▨▨▨▨╱
   ───────────────────────────
   Strung   04 Mar 2026
   Setup    RPM Blast 1.25
            24 / 22 lb
   By       YourShop

   [ Book a restring ]
   [ Is this yours? Claim it ]   ← the viral loop
```

**Owning player** → full history, feedback prompt, request restring.
**Stringer who did the job** → straight into "restring same again". Scan-to-relog is the single biggest speed win in a busy shop.

### 4.7 Due-this-week review queue (`/app/due`)
```
┌────────────────────────────────────────────────┐
│  Due this week                    7 customers  │
│  [ Auto-send: ON ▾ ]      sends Wed 9am        │
├────────────────────────────────────────────────┤
│  [✓] Alex Tan      due Wed   ▨▨▨  WhatsApp     │
│      "Hi Alex, your Pure Aero is about due..." │
│                              [Edit] [Skip]     │
│  [✓] Wei Ming      due Thu   ▨▨▨  WhatsApp     │
│  [ ] Sarah L.      due Fri   ▨▨   ⚠ paused     │
├────────────────────────────────────────────────┤
│  [ Send 5 now ]                                │
└────────────────────────────────────────────────┘
```
Default to review-mode for the first 30 days of a tenant's life, then prompt to switch to auto. Trust in automated messaging to *their* customers has to be earned, and the prompt to switch is a great retention touchpoint.

---

## 5. Component inventory

**Primitives:** Button (primary/secondary/ghost/danger), Input, NumberStepper (tension — ±0.5 lb, big targets), Select, Combobox (async typeahead), Toggle, Radio card, Sheet, Dialog, Toast, Tabs, Badge, Skeleton, EmptyState, ErrorState.

**Domain components — the ones worth real care:**

| Component | Notes |
|---|---|
| `<StringBedMeter racket size state />` | §2.4. Reads pattern from racket, renders true mains/crosses count. The signature. |
| `<TensionPair mains crosses unit />` | Mono, tabular. Handles lb⇄kg display without ever mutating stored value. |
| `<SetupSummary job />` | The canonical "RPM Blast 1.25 · 24/22" line. Used in ~12 places — define it once. |
| `<RacketCombobox sport />` | Async catalogue search, debounce 200ms, shows key specs in the option row, "can't find it? add it" at the bottom. |
| `<StringCombobox sport />` | Same, grouped by material family. |
| `<QRScanner onResult />` | Camera stream, torch toggle, manual short-code fallback input, permission-denied state. |
| `<LabelPreview job format />` | Live canvas preview at true physical scale. |
| `<JobRow job density />` | Two densities: tablet-dense and phone-comfortable. |
| `<ReasoningList reasons />` | Renders engine explanations. Collapsed to 2 lines by default, expands. **Must degrade gracefully to zero reasons** — the real engine may not emit them (backend doc §7.3). If empty, hide the "Why this" block entirely rather than rendering an empty heading. |
| `<ConsentGate />` | Wraps anything showing cross-stringer history. Fails closed. |

---

## 6. Label rendering & printing

Two rendering paths, both driven from the same layout definition:

1. **Client-side preview** — canvas, true-to-size at the selected label dimensions, live as the stringer edits.
2. **Server-side export** — PDF (vector) + PNG (300dpi) generated by the backend (backend doc §11). The client never generates the downloadable artifact; you want it deterministic and reproducible from a job ID.

**Formats to ship in v1:**

| Preset | Size | Notes |
|---|---|---|
| Dymo 99012 | 89 × 36 mm | Most common in existing stringing shops |
| Brother QL 62mm | 62 mm continuous | Native iOS support is genuinely better |
| Niimbot D11 | 40 × 30 mm | ~S$25 device — the home-stringer default. **Prioritise this one.** |
| A4 sheet | 24-up, Avery L7159 | For people with no label printer at all |

**QR constraints:** error correction level M, quiet zone ≥4 modules, minimum printed size 15mm. **Test scans on a sticker that's been sweated on and rubbed against a bag for six weeks before you ship.** A QR that doesn't scan in the real world silently kills the feature.

Printing itself: browser print dialog with `@page` sizing for v1. Direct printer integration (Brother/Dymo SDKs) is native-only and belongs in Phase 4+.

---

## 7. State & data

```
Server state    → TanStack Query. Cache keys namespaced by tenant.
Form state      → react-hook-form + zod, schemas SHARED with backend (single source of truth)
Client state    → React context only for: session, tenant, unit preference, offline queue
URL state       → filters, search, pagination. Deep-linkable. No hidden state in components.
```

**Optimistic updates for:** mark strung, mark ready, mark collected, skip reminder. These are the high-frequency bench actions and they must feel instant.
**Never optimistic:** creating a job, sending a message, taking payment. Wrong outcomes here are expensive and confusing.

---

## 8. Offline

A home stringer's garage has bad wifi. A tournament venue has worse.

**Must work offline:**
- Viewing today's queue and any job opened in the last 7 days
- Logging a new job (queued, syncs on reconnect)
- Mark strung / ready / collected

**Cannot work offline** (show honest state, don't fake it):
- Catalogue search beyond the locally-cached recent items
- Recommendations
- Sending messages
- Payments

**Implementation:** IndexedDB queue with idempotency keys generated client-side (backend doc §6.3 accepts them). Service worker for shell + last-7-days data. Persistent banner: `Offline · 2 jobs waiting to sync`. On reconnect, replay in order, surface conflicts rather than silently overwriting.

---

## 9. Empty, loading, error

Every list gets all four states designed, not just the happy path.

| State | Treatment |
|---|---|
| Empty (first run) | An invitation with the action inline: *"No jobs yet. Log your first — takes about 20 seconds."* + button |
| Empty (filtered) | *"No jobs match 'blade'."* + clear-filters |
| Loading | Skeletons matching final layout. No spinners on lists. |
| Error | What happened + what to do. Retry button. Never a raw error code in the primary line. |
| Offline | Distinct from error. Reassuring: work is saved, not lost. |

---

## 10. Accessibility & the bench environment

Standard bar: WCAG 2.2 AA, visible keyboard focus, `prefers-reduced-motion` honoured, semantic landmarks, form labels always present (never placeholder-as-label).

**Plus, specific to this product:**
- **Touch targets ≥48px** in `/app`. Hands are dirty, sometimes wet, sometimes wearing a glove.
- **Sunlight-readable contrast** — outdoor club stringing is real. Test the fluoro accent at 5% screen brightness in daylight; if it fails, add a high-contrast toggle rather than compromising the palette.
- **String-bed meter is never colour-alone.** The slackness of the drawn strings carries the same information as the hue, and every meter has a text percentage or state label beside it. ~8% of male players are red-green colour blind and this is your core mechanic.
- **One-handed reach** on phone: primary actions in the bottom third.
- Screen-reader label for the meter: `"String life 73 percent, due in about 12 days"` — never `"chart"`.

---

## 11. Performance budgets

| Metric | Budget |
|---|---|
| `/r/[shortCode]` LCP, 4G | < 1.5s |
| `/r/[shortCode]` JS shipped | < 60kb gzipped |
| `/app` shell TTI, cached | < 1.0s |
| Scan → job saved (repeat path) | **< 5s end to end** |
| Catalogue typeahead response | < 200ms perceived (optimistic local cache first) |
| String bed meter render | < 16ms at 24px, list of 50 |

Ship the passport page as a route-segment with near-zero client JS. It's the page strangers see and the one most likely to be on a slow phone.

---

## 12. Units & i18n

- **Store canonical in lb** (backend doc §3). Display per user preference — lb (US/SEA) or kg (much of Europe). Never round-trip through the display unit.
- Gauge: mm primary, US gauge number (`16L`, `17`) as a secondary label — both are in daily use.
- Dates: relative for recent (`2h ago`, `due Wed`), absolute beyond 7 days.
- i18n scaffolding from day one (`next-intl`), English only at launch. Second locale is likely Simplified Chinese or Bahasa given the SEA market — don't hardcode strings.
- Currency from the tenant's settings; never assume USD.

---

## 13. Analytics events

Minimum viable instrumentation — the master doc's metrics (§14) depend on these existing from day one.

```
job_logged            { path: scan|search|new_customer, repeat: bool, duration_ms }
job_same_again_used   { }
recommendation_viewed { sport, surface: public|stringer|player }
recommendation_used   { accepted: primary|alt_comfort|alt_durable|none }
reminder_reviewed     { action: sent|skipped|edited }
reminder_clicked      { stage: t_minus_7|t_zero }
booking_from_reminder { }          ← the single most important event in the product
feedback_submitted    { verdict, days_after_job }
racket_claimed        { source: qr_scan|link }
label_printed         { format }
offline_sync_replayed { queued_count, conflicts }
```

`booking_from_reminder` / `reminder_clicked` is the reminder→booking conversion rate. If that number is under 15%, nothing else in the product matters. **Instrument it before you instrument anything else.**

---

## 14. Repo shape

```
/app
  /(marketing)          landing, find-your-setup
  /(public)/r/[code]    passport — server-rendered, minimal JS
  /(stringer)/app/*     console
  /(player)/my/*        portal
/components
  /ui                   primitives
  /domain               StringBedMeter, TensionPair, QRScanner, ...
/lib
  /api                  typed client, generated from backend OpenAPI
  /schemas              zod — SHARED with backend
  /offline              IndexedDB queue, sync
  /units                lb⇄kg, gauge conversion — pure, heavily tested
/styles                 tokens.css
```

**Share the zod schemas with the backend.** One definition of what a valid job is, validated on both sides. This is the highest-leverage decision in the whole repo layout.

---

## 15. Frontend build order

| Phase | Weeks | Ship |
|---|---|---|
| **F0** | 1 | Tokens, primitives, StringBedMeter, TensionPair. Storybook. |
| **F1** | 2–5 | Auth screens, `/app` Today, new-job flow incl. SAME AGAIN, job detail, customers. **Enough to run your own shop.** |
| **F2** | 6–7 | QR scanner, label preview + print, `/r/[code]` all three states |
| **F3** | 8–9 | Recommendation wizard (public + stringer), reasoning UI, result + degraded states — **all against the mock engine**. Not blocked on the real engine, and shouldn't change when it lands. |
| **F4** | 10–11 | Due-this-week queue, player portal `/my`, feedback capture |
| **F5** | 12–13 | Offline queue, empty/error state pass, a11y audit, perf budgets |
| **F6** | 14+ | Inventory, analytics, settings depth, billing screens |

**F1 gate:** you personally run every job through it for four weeks before anyone else touches it. Every annoyance you feel is a bug a paying stringer would have churned over.

---

## 16. Open frontend questions

1. **Does the player portal need push at all**, or is WhatsApp sufficient? (Leaning: WhatsApp only for v1. Push is a Phase 4 nice-to-have.)
2. **Tablet vs phone for the stringer console** — which do your 12 interviewees (master doc §11, Phase 0) actually have at the bench? This determines the primary breakpoint and it's worth asking explicitly.
3. **Is "SAME AGAIN" one tap or two?** One tap is faster; two prevents mis-logs. Instrument the correction rate in F1 and decide with data.
4. **Public passport: show the stringer's price?** Helps booking conversion, but stringers may not want public pricing. Probably a tenant setting, defaulted off.
5. **Does the anonymous passport page show the string brand?** It's a mild competitive disclosure for the stringer, but hiding it makes the page much less useful. Lean toward showing it.
