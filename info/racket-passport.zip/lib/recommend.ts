import { getString, lastJobForRacket, modelForRacket } from './mock-data'
import type { Job, RacketModel } from './types'

/**
 * SEAM — replace the body of `recommend()` with the real engine.
 *
 * The UI only ever touches this interface, so swapping the implementation
 * is a single-file change. Nothing downstream reads the internals.
 */
export interface Recommendation {
  tensionMainsLb: number
  tensionCrossesLb: number
  stringId: string
  gaugeMm: number
  /** Plain-language reasons. The UI shows at most two. */
  because: string[]
  /** 'same-again' short-circuits the wizard entirely. */
  source: 'same-again' | 'engine' | 'default'
  confidence: 'high' | 'medium' | 'low'
}

export interface GuardrailWarning {
  kind: 'over-max' | 'under-min'
  message: string
}

/** Advisory only — a stringer can always override. */
export function checkGuardrail(
  model: RacketModel,
  tensionLb: number,
): GuardrailWarning | undefined {
  if (model.maxTensionLb && tensionLb > model.maxTensionLb) {
    return {
      kind: 'over-max',
      message: `Above ${model.brand}'s stated max of ${model.maxTensionLb}lb for this frame.`,
    }
  }
  return undefined
}

/** Derived from the previous job — this is what SAME AGAIN reads. */
export function sameAgain(racketId: string): Recommendation | undefined {
  const last = lastJobForRacket(racketId)
  if (!last) return undefined

  const because: string[] = []
  if (last.feedback === 'spot-on') because.push('Last job felt spot-on')
  if (last.snapped) because.push('Last set snapped early')
  if (last.feedback === 'too-tight') because.push('Last job played too tight')

  return {
    tensionMainsLb: last.tensionMainsLb,
    tensionCrossesLb: last.tensionCrossesLb,
    stringId: last.mainsStringId,
    gaugeMm: last.gaugeMm,
    because,
    source: 'same-again',
    confidence: 'high',
  }
}

/**
 * MOCK. Nudges the last setup using feedback and frame stiffness so the UI has
 * something believable to render. The real engine replaces this wholesale.
 */
export function recommend(racketId: string): Recommendation {
  const model = modelForRacket(racketId)
  const last = lastJobForRacket(racketId)

  if (!last) {
    const isBadminton = model.sport === 'badminton'
    return {
      tensionMainsLb: isBadminton ? 26 : 52,
      tensionCrossesLb: isBadminton ? 28 : 50,
      stringId: isBadminton ? 'st-bg65' : 'st-nxt',
      gaugeMm: isBadminton ? 0.7 : 1.3,
      because: ['No history yet — starting from a safe mid-range'],
      source: 'default',
      confidence: 'low',
    }
  }

  let delta = 0
  const because: string[] = []

  if (last.feedback === 'too-tight') {
    delta = -2
    because.push('You said the last job played too tight')
  } else if (last.feedback === 'too-loose') {
    delta = 2
    because.push('You said the last job played too loose')
  } else if (last.snapped || last.feedback === 'broke-early') {
    delta = -1
    because.push('Last set broke early — easing off helps it last')
  } else if (last.feedback === 'spot-on') {
    because.push('Last job felt spot-on, holding it')
  }

  if (model.ra >= 68 && delta === 0) {
    delta = -1
    because.push(`${model.model} is a firm frame (RA ${model.ra})`)
  }

  return {
    tensionMainsLb: last.tensionMainsLb + delta,
    tensionCrossesLb: last.tensionCrossesLb + delta,
    stringId: last.mainsStringId,
    gaugeMm: last.gaugeMm,
    because: because.slice(0, 2),
    source: 'engine',
    confidence: last.feedback ? 'high' : 'medium',
  }
}

/** Human label for a recommendation's string + gauge. */
export function describeSetup(rec: Recommendation): string {
  const s = getString(rec.stringId)
  return `${s.brand} ${s.name} ${rec.gaugeMm.toFixed(2)}mm`
}

/** Does this job match the recommendation exactly? Used to badge overrides. */
export function isOverride(job: Pick<Job, 'tensionMainsLb'>, rec: Recommendation) {
  return job.tensionMainsLb !== rec.tensionMainsLb
}
