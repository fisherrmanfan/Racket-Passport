'use client'

import { createContext, useCallback, useContext, useMemo, useState } from 'react'
import { jobs as seedJobs } from '@/lib/mock-data'
import type { Job, Unit } from '@/lib/types'

/**
 * In-memory store for the prototype. Mirrors the shape a server action layer
 * would expose, so wiring a real backend later is a swap of these four calls.
 */
interface JobStore {
  jobs: Job[]
  unit: Unit
  setUnit: (unit: Unit) => void
  createJob: (job: Omit<Job, 'id' | 'status'>) => Job
  markReady: (id: string) => void
  markCollected: (id: string) => void
  /** Toast-style confirmation for the last action. */
  flash?: string
  clearFlash: () => void
}

const Ctx = createContext<JobStore | null>(null)

export function JobStoreProvider({ children }: { children: React.ReactNode }) {
  const [jobs, setJobs] = useState<Job[]>(seedJobs)
  const [unit, setUnit] = useState<Unit>('lb')
  const [flash, setFlash] = useState<string | undefined>()

  const createJob = useCallback((input: Omit<Job, 'id' | 'status'>) => {
    const job: Job = { ...input, id: `j-${Date.now()}`, status: 'queue' }
    setJobs((prev) => [job, ...prev])
    setFlash('Job added to the queue')
    return job
  }, [])

  const markReady = useCallback((id: string) => {
    setJobs((prev) =>
      prev.map((j) =>
        j.id === id
          ? {
              ...j,
              status: 'ready',
              strungAt: new Date().toISOString(),
              dueAt: new Date(Date.now() + 42 * 86_400_000).toISOString(),
            }
          : j,
      ),
    )
    setFlash('Marked ready — customer notified')
  }, [])

  const markCollected = useCallback((id: string) => {
    setJobs((prev) =>
      prev.map((j) => (j.id === id ? { ...j, status: 'collected' } : j)),
    )
    setFlash('Collected')
  }, [])

  const clearFlash = useCallback(() => setFlash(undefined), [])

  const value = useMemo(
    () => ({ jobs, unit, setUnit, createJob, markReady, markCollected, flash, clearFlash }),
    [jobs, unit, createJob, markReady, markCollected, flash, clearFlash],
  )

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useJobStore() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('useJobStore must be used inside JobStoreProvider')
  return ctx
}
